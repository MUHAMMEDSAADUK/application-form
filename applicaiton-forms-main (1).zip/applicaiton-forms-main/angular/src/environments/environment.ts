import { Environment } from '@abp/ng.core';

const baseUrl = 'http://localhost:4201';

export const environment = {
  production: false,
  application: {
    baseUrl,
    name: 'ApplicatioForms',
    logoUrl: '',
  },
  oAuthConfig: {
    issuer: 'https://localhost:44396',
    redirectUri: baseUrl,
    clientId: 'ApplicatioForms_App',
    responseType: 'code',
    scope: 'offline_access ApplicatioForms',
    requireHttps: true,
  },
  apis: {
    default: {
      url: 'https://localhost:44396',
      rootNamespace: 'ionob.ApplicatioForms',
    },
  },
} as Environment;
