import { Environment } from '@abp/ng.core';

const baseUrl = 'https://applications.islahiya.com';

export const environment = {
  production: true,
  application: {
    baseUrl,
    name: 'ApplicatioForms',
    logoUrl: '',
  },
  oAuthConfig: {
    issuer: 'https://applicationapi.islahiya.com',
    redirectUri: baseUrl,
    clientId: 'ApplicatioForms_App',
    responseType: 'code',
    scope: 'offline_access ApplicatioForms',
    requireHttps: true
  },
  apis: {
    default: {
      url: 'https://applicationapi.islahiya.com',
      rootNamespace: 'ionob.ApplicatioForms',
    },
  },
} as Environment;
