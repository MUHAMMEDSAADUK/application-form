import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';
import { SharedModule } from '../shared/shared.module';
import { ViewfilesRoutingModule } from './viewfiles-routing.module';
import { ViewfilesComponent } from './viewfiles.component';



@NgModule({
  declarations: [ViewfilesComponent],
  imports: [SharedModule, ViewfilesRoutingModule,NgSelectModule,],
  providers:[FileDownloadService]
})


export class ViewfilesModule {}