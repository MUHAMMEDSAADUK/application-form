import { Component, OnInit, Injector } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { CreateorEditTcForm, TcFormApplicationService } from '@proxy/tc-upload-form';
import { first } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { EntityDto, RestService } from '@abp/ng.core';
import { Observable, ReplaySubject } from 'rxjs';
import { ToasterService } from '@abp/ng.theme.shared';

@Component({
  selector: 'app-viewfiles',
  templateUrl: './viewfiles.component.html',
  styleUrls: ['./viewfiles.component.scss'],
})
export class ViewfilesComponent implements OnInit {
  studentTcList: CreateorEditTcForm[];
  isModalOpen: boolean = false;
  ModalOpen: boolean = false;
  SelectedAttachment: any;
  UpdateDetails: any;
  loading = false;
  submitted = false;
  alertService: any;
  createorEditTcForm: any;
  tcnumber: string = '';
  file: File;
  NewStudent: boolean;

  constructor(
    injector: Injector,
    private _viewfilesServiceProxy: TcFormApplicationService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private uploadService: FileDownloadService,
    private router: Router,
    private httpRequest: HttpClient,
    private requestService: RestService,
    private toaster: ToasterService,
    private tcFormService: TcFormApplicationService
  ) {}

  ngOnInit(): void {
    this.getAllfiles();
  }

  TcUploadApplication() {
    this.createorEditTcForm.push({
      id: null,
      name: null,
      tcNumber: null,
      class: null,
      tcAttchement: null,
    });
  }

  getAllfiles() {
    this._viewfilesServiceProxy.getAll().subscribe(result => {
      this.studentTcList = result;
      // console.log(result, 'Result');
    });
  }

  //base64 string
  base64Output: string;
  onFileSelected(event) {
    //debugger;
    console.log(event);
    const file: File = event.target.files[0];
    this.convertFile(file).subscribe(base64 => {
      this.base64Output = base64;
    });
  }
  convertFile(file: File): Observable<string> {
    // debugger;
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = event => result.next(btoa(event.target.result.toString()));
    return result;
  }

  openDocument(imageSource) {
    //this.isModalOpen = true;
    this.SelectedAttachment = imageSource;
    this.UpdateDetails = this.studentTcList;
    //this.modalCtrl.create(ModelPage,{"img":imageSource}).present();
  }
  addStudent() {
    this.createorEditTcForm = new EntityDto();
    this.NewStudent = true;
    this.isModalOpen = true;
  }

  EditDoc(items: CreateorEditTcForm) {
    console.log(items, 'Edit Item');
    this.createorEditTcForm = items;
    this.NewStudent = false;
    this.isModalOpen = true;
  }

  apiName = 'Default';

  UpdateData() {
    this.createorEditTcForm.base64string = this.base64Output;
    this._viewfilesServiceProxy.tcFormUpdate(this.createorEditTcForm).subscribe(res => {
      this.isModalOpen = false;
    });
  }

  DeleteDoc(items: CreateorEditTcForm) {
    debugger;
    console.log(items, 'delete Item');
    this.createorEditTcForm = items;
    this.ModalOpen = true;
  }

  Delete(tcNumber: string) {
    debugger;
    this._viewfilesServiceProxy.tcFormDelete(this.createorEditTcForm.tcNumber).subscribe(error => {
      // this.createorEditTcForm(tcNumber);
      console.log(error);
      this.ModalOpen = false;
      // this._viewfilesServiceProxy.getAll();
      this.getAllfiles();
    });
  }
  FileUpload(files: FileList) {
    this.file = files.item(0);
  }

  CreateData() {
    this.createorEditTcForm.base64string = this.base64Output;
    if (this.createorEditTcForm.name == null) {
      this.toaster.error("Student's Name Required");
      return;
    }
    if (this.createorEditTcForm.tcNumber == null) {
      this.toaster.error('TC Number Required');
      return;
    }

    if (this.createorEditTcForm.class == null) {
      this.toaster.error("Student's Class Std. Required");
      return;
    }

    if (this.createorEditTcForm.base64string == null) {
      this.toaster.error("Student's Transfer Certificate Required");
      return;
    }
    // if (this.tcFormService.checkFileExistByTcNumber(this.tcnumber)) {
    //   this.toaster.error('Transfer Certificate Already Uploaded');
    //   return;
    // }

    this._viewfilesServiceProxy.tcFormCreate(this.createorEditTcForm).subscribe(res => {
      if (res != null) {
        this.isModalOpen = false;
        this.getAllfiles();
      }
    });
  }
}
