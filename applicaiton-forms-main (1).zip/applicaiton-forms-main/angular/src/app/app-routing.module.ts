import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
  },
  {
    path: 'account',
    loadChildren: () => import('@abp/ng.account').then(m => m.AccountModule.forLazy()),
  },
  {
    path: 'identity',
    loadChildren: () => import('@abp/ng.identity').then(m => m.IdentityModule.forLazy()),
  },
  {
    path: 'tenant-management',
    loadChildren: () =>
      import('@abp/ng.tenant-management').then(m => m.TenantManagementModule.forLazy()),
  },
  {
    path: 'setting-management',
    loadChildren: () =>
      import('@abp/ng.setting-management').then(m => m.SettingManagementModule.forLazy()),
  },
  { path: 'applicants-details', loadChildren: () => import('./applicants-detail/applicants-detail.module').then(m => m.ApplicantsDetailModule) },
  { path: 'tcupload', loadChildren: () => import('./tcupload/tcupload.module').then(m => m.TcuploadModule) },
  { path: 'tcdownload', loadChildren: () => import('./tcdownload/tcdownload.module').then(m => m.TcdownloadModule) },
  { path: 'viewfiles', loadChildren: () => import('./viewfiles/viewfiles.module').then(m => m.ViewfilesModule) },
  { path: 'applicants-hss', loadChildren: () => import('./applicants-hss/applicants-hss.module').then(m => m.ApplicantsHssModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
