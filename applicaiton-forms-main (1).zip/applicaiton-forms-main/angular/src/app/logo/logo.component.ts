import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logo',
  template:`<span class="logoText">Application Form</span>
`,
  styleUrls: ['./logo.component.scss']
})
export class LogoComponent {

  constructor() { }



}
