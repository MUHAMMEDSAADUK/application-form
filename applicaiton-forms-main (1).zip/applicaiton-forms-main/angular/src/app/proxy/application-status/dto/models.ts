import type { EntityDto } from '@abp/ng.core';

export interface GetApplicationStatusDto extends EntityDto<number> {
  applicationName?: string;
  isOpen: boolean;
}

export interface SetApplicationStatusDto {
  applicationId: number;
  applicationName?: string;
  isOpen: boolean;
}
