import type { GetApplicationStatusDto, SetApplicationStatusDto } from './dto/models';
import { RestService } from '@abp/ng.core';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ApplicationStatusAppserviceService {
  apiName = 'Default';

  getApplicationStatusByApplcationname = (applcationname: string) =>
    this.restService.request<any, GetApplicationStatusDto>({
      method: 'GET',
      url: '/api/app/application-status-appservice/application-status',
      params: { applcationname },
    },
    { apiName: this.apiName });

  setApplicationStatusByInput = (input: SetApplicationStatusDto) =>
    this.restService.request<any, GetApplicationStatusDto>({
      method: 'POST',
      url: '/api/app/application-status-appservice/set-application-status',
      body: input,
    },
    { apiName: this.apiName });

  constructor(private restService: RestService) {}
}
