import type { CreateorEditTcForm } from './models';
import { RestService } from '@abp/ng.core';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TcFormApplicationService {
  apiName = 'Default';

  checkFileExistByTcNumber = (TcNumber: string) =>
    this.restService.request<any, boolean>({
      method: 'POST',
      url: '/api/app/tc-form-application/check-file-exist',
      params: { tcNumber: TcNumber },
    },
    { apiName: this.apiName });

  getAll = () =>
    this.restService.request<any, CreateorEditTcForm[]>({
      method: 'GET',
      url: '/api/app/tc-form-application',
    },
    { apiName: this.apiName });

  getForEditByInput = (input: CreateorEditTcForm) =>
    this.restService.request<any, void>({
      method: 'GET',
      url: '/api/app/tc-form-application/for-edit',
      params: { name: input.name, tcNumber: input.tcNumber, class: input.class, tcAttchement: input.tcAttchement, base64string: input.base64string, id: input.id },
    },
    { apiName: this.apiName });

  tcFormCreate = (input: CreateorEditTcForm) =>
    this.restService.request<any, CreateorEditTcForm>({
      method: 'POST',
      url: '/api/app/tc-form-application/tc-form-create',
      body: input,
    },
    { apiName: this.apiName });

  tcFormDelete = (TcNumber: string) =>
    this.restService.request<any, boolean>({
      method: 'POST',
      url: '/api/app/tc-form-application/tc-form-delete',
      params: { tcNumber: TcNumber },
    },
    { apiName: this.apiName });

  tcFormUpdate = (input: CreateorEditTcForm) =>
    this.restService.request<any, boolean>({
      method: 'POST',
      url: '/api/app/tc-form-application/tc-form-update',
      body: input,
    },
    { apiName: this.apiName });

  constructor(private restService: RestService) {}
}
