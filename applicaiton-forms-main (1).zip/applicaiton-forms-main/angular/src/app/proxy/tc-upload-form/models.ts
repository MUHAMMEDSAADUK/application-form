import type { EntityDto } from '@abp/ng.core';

export interface CreateorEditTcForm extends EntityDto<number> {
  name?: string;
  tcNumber?: string;
  class: number;
  tcAttchement?: string;
  base64string?: string;
}
