
export interface FileDto {
  fileName: string;
  fileType?: string;
  fileToken: string;
}
