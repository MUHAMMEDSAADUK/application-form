import * as ApplicationDetail from './application-detail';
import * as ApplicatiosForms from './applicatios-forms';
export { ApplicationDetail, ApplicatiosForms };
