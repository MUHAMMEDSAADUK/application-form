import { RestService } from '@abp/ng.core';
import { Injectable } from '@angular/core';
import type { GetApplicationForViewDto } from '../application-detail/models';
import type { CreateOrEditApplicationDto, DateOfBirth, GetAllApplicationFormDto } from '../../application-forms/models';
import type { FileDto } from '../../io-nob/applicatio-forms/data-exporting/models';

@Injectable({
  providedIn: 'root',
})
export class ApplicationFormService {
  apiName = 'Default';

  createNewApplicationByCreateOrEditApplication = (createOrEditApplication: CreateOrEditApplicationDto) =>
    this.restService.request<any, number>({
      method: 'POST',
      url: '/api/app/application-form/new-application',
      body: createOrEditApplication,
    },
    { apiName: this.apiName });

  findAgeByDateofbirth = (dateofbirth: DateOfBirth) =>
    this.restService.request<any, number>({
      method: 'POST',
      url: '/api/app/application-form/find-age',
      body: dateofbirth,
    },
    { apiName: this.apiName });

  getAllByInput = (input: GetAllApplicationFormDto) =>
    this.restService.request<any, GetApplicationForViewDto[]>({
      method: 'GET',
      url: '/api/app/application-form',
      params: { filter: input.filter, name: input.name, dateOfBirth: input.dateOfBirth, mobileNumber: input.mobileNumber, email: input.email },
    },
    { apiName: this.apiName });

  getApplicationReportToExcel = () =>
    this.restService.request<any, FileDto>({
      method: 'GET',
      url: '/api/app/application-form/application-report-to-excel',
    },
    { apiName: this.apiName });

  constructor(private restService: RestService) {}
}
