import type { AdditionalQualificationDto, ExperienceDto, QualificationDto } from '../../application-forms/models';

export interface GetApplicationForViewDto {
  name?: string;
  gender?: string;
  dateOfBirth?: string;
  age?: number;
  fathersName?: string;
  houseName?: string;
  postOffice?: string;
  pin?: string;
  district?: string;
  state?: string;
  country?: string;
  nativePlace?: string;
  residentPlace?: string;
  mobileNumber?: string;
  whatsAppNumber?: string;
  email?: string;
  address?: string;
  otherAchievements?: string;
  experiences: ExperienceDto[];
  qualifications: QualificationDto[];
  additionalQualifications: AdditionalQualificationDto[];
  image?: string;
  registrationNumber?: number;
  appliedPost?: string;
  isHighSchool: boolean;
}
