import type { EntityDto } from '@abp/ng.core';

export interface AdditionalQualificationDto extends EntityDto<number> {
  qualifaication?: string;
  boardOrUniversity?: string;
  percentageMark?: number;
  applicationId?: number;
}

export interface ExperienceDto extends EntityDto<number> {
  designation?: string;
  nameOfInstitution?: string;
  govtOrPrivate?: string;
  duration?: string;
  applicationId?: number;
  durationFrom?: string;
  durationTo?: string;
}

export interface QualificationDto extends EntityDto<number> {
  qualifaication?: string;
  boardOrUniversity?: string;
  percentageMark?: number;
  applicationId?: number;
}

export interface CreateOrEditApplicationDto extends EntityDto<number> {
  name?: string;
  gender?: string;
  dateOfBirth?: string;
  age?: number;
  fathersName?: string;
  houseName?: string;
  postOffice?: string;
  pin?: string;
  district?: string;
  state?: string;
  country?: string;
  nativePlace?: string;
  residentPlace?: string;
  mobileNumber?: string;
  whatsAppNumber?: string;
  email?: string;
  otherAchievements?: string;
  experiences: ExperienceDto[];
  qualifications: QualificationDto[];
  additionalQualifications: AdditionalQualificationDto[];
  image?: string;
  registrationNumber?: number;
  appliedPost?: string;
  isHighSchool: boolean;
}

export interface DateOfBirth {
  dateofBirth?: string;
}

export interface GetAllApplicationFormDto {
  filter?: string;
  name?: string;
  dateOfBirth?: string;
  mobileNumber?: string;
  email?: string;
}
