import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FileDto } from '@proxy/io-nob/applicatio-forms/data-exporting';
import { CreateorEditTcForm } from '@proxy/tc-upload-form';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable()
export class FileDownloadService {
  async tcFormUpdate(input: CreateorEditTcForm, file: File) {
    debugger;
    let formData = new FormData();
    formData.append('name', input.name);
    formData.append('tcNumber', input.tcNumber);
    formData.append('class', input.class.toString());
    formData.append('file', file);

    var url = environment.apis.default.url + '/File/UpdateFile';
    return await this.httpRequest.post<string>(url, formData);
  }

  constructor(private httpRequest: HttpClient) {}

  downloadTempFile(file: FileDto) {
    const url =
      environment.apis.default.url +
      '/File/DownloadTempFile?fileType=' +
      file.fileType +
      '&fileToken=' +
      file.fileToken +
      '&fileName=' +
      file.fileName;

    location.href = url; //TODO: This causes reloading of same page in Firefox
  }
  uploadFile(input: CreateorEditTcForm, file: File) {
    debugger;
    let formData = new FormData();
    formData.append('name', input.name);
    formData.append('tcNumber', input.tcNumber);
    formData.append('class', input.class.toString());
    formData.append('file', file);
    formData.append('tcAttchement', input.tcAttchement);

    var url = environment.apis.default.url + '/File/UploadTcDetails';
    this.httpRequest.post(url, formData).subscribe(res => {});
  }
  downloadTc(fileName: string) {
    const url = environment.apis.default.url + '/File/DownloadTc?filename=' + fileName;
    location.href = url;
    // var url = environment.apis.default.url + '/File/CheckFileExist';
    // this.httpRequest.post(url,fileName).subscribe(
    // (res)=>{
    //             const url =environment.apis.default.url + '/File/DownloadTc?filename=' + fileName;
    // location.href = url;
    // },
    // (error)=>{
    //     return error.toString();
    // }
    // );
  }
}
