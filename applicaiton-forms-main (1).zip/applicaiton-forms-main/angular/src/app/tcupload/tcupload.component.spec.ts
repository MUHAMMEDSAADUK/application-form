import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TcuploadComponent } from './tcupload.component';

describe('TcuploadComponent', () => {
  let component: TcuploadComponent;
  let fixture: ComponentFixture<TcuploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TcuploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TcuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
