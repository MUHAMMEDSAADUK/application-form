import { ToasterService } from '@abp/ng.theme.shared';
import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { resetFakeAsyncZone } from '@angular/core/testing';
import {CreateorEditTcForm, TcFormApplicationService} from '@proxy/tc-upload-form';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';

@Component({
  selector: 'app-tcupload',
  templateUrl: './tcupload.component.html',
  styleUrls: ['./tcupload.component.scss']
})
export class TcuploadComponent implements OnInit {
  
  createorEditTcForm = {} as CreateorEditTcForm;
  file:File;

  tcnumber:string="";
  //file upload

//add misssing file too (https://stackoverflow.com/questions/47936183/angular-file-upload)
//the add blob function in  ITcFormApplication.cs for backend (https://docs.abp.io/en/abp/latest/Blob-Storing)

  constructor(
    private _tcFORMSERVICE:TcFormApplicationService,
    private uploadService:FileDownloadService,
    private tcFormService:TcFormApplicationService,
    private toaster:ToasterService){}
  
    
  
  ngOnInit(): void {
   // this.TcUploadApplication();
  }



  // TcUploadApplication() {
  //   this.CreateorEditTcForm.push({
  //     id: null,
  //     name: null,
  //     tcNumber: null,
  //     class: null,
  //     tcAttchement: null,
  //   });
  // }
  
  Save(){
    // this._tcFORMSERVICE.uploadTcByInput(this.createorEditTcForm).subscribe((res)=>{
      
    // })
    if(this.createorEditTcForm.name==null){
      this.toaster.error("Student's Name Required");
      return;

    }
    if(this.createorEditTcForm.tcNumber==null){
      this.toaster.error("TC Number Required");
      return;

    }
    if(this.createorEditTcForm.class==null){
      this.toaster.error("Student's Class Std. Required");
      return;
      }
      
      if(this.file==null){
        this.toaster.error("Student's Transfer Certificate Required");
        return;
      }
      //  if(this.tcFormService.checkFileExistByTcNumber(this.tcnumber)){
      //   this.toaster.error("Transfer Certificate Already Uploaded");
      //    return;
      //  }
    
    else{
    debugger;
    this.toaster.success("Document Uploaded");
    this.uploadService.uploadFile(this.createorEditTcForm,this.file);
    this.createorEditTcForm = {} as CreateorEditTcForm;
    
  }
}
isDisabled = false;
  FileUpload(files: FileList){
    this.file = files.item(0);
  }
  // download(){
  //   this.uploadService.downloadTc("abc.pdf");
  // } 
    download(){
      debugger;
    if(this.tcnumber==null||this.tcnumber==""){
      this.toaster.error("Please Enter TC Number");
      return;
    }
      else{
        this.uploadService.downloadTc(this.tcnumber+".pdf");
        
      }
    }
    updateData(){

    }
  } 

