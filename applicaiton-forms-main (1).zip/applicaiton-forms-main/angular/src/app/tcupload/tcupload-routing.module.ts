import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplicationLayoutComponent } from '@abp/ng.theme.basic';
import { TcuploadComponent } from './tcupload.component';


const routes: Routes = [{ path: '', component: TcuploadComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TcuploadRoutingModule {}
