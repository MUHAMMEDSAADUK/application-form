import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';
import { SharedModule } from '../shared/shared.module';
import { TcuploadRoutingModule } from './tcupload-routing.module';
import { TcuploadComponent } from './tcupload.component';


@NgModule({
  declarations: [TcuploadComponent],
  imports: [SharedModule, TcuploadRoutingModule,NgSelectModule],
  providers:[FileDownloadService]
})
export class TcuploadModule {}