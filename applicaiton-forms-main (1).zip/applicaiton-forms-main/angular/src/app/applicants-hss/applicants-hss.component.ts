import { AuthService, validateCreditCard } from '@abp/ng.core';
import { ConfirmationService, ToasterService } from '@abp/ng.theme.shared';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  AdditionalQualificationDto,
  CreateOrEditApplicationDto,
  DateOfBirth,
  ExperienceDto,
  QualificationDto,
} from '@proxy/application-forms';
import { ApplicationStatusAppserviceService } from '@proxy/application-status';
import { ApplicationFormService } from '@proxy/ionob/applicatios-forms';

import { OAuthService } from 'angular-oauth2-oidc';

@Component({
  selector: 'app-applicants-hss',
  templateUrl: './applicants-hss.component.html',
  styleUrls: ['./applicants-hss.component.scss'],
})
export class ApplicantsHss implements OnInit {
  get hasLoggedIn(): boolean {
    return this.oAuthService.hasValidAccessToken();
  }
  currentTab = 0;
  personalDetails: boolean;
  qualification: boolean;
  experience: boolean;
  displaydetails: boolean;
  createorEditApplication = {} as CreateOrEditApplicationDto;
  quatificationDtos: QualificationDto[] = new Array<QualificationDto>();
  additionalquatificationDtos: AdditionalQualificationDto[] =
  new Array<AdditionalQualificationDto>();
  experienceDtos: ExperienceDto[] = new Array<ExperienceDto>();
  isHighSchool: boolean;
  isSucess = false;
  isApplicationOpen: boolean = true;
  constructor(
    private oAuthService: OAuthService,
    private authService: AuthService,
    private applicatioService: ApplicationFormService,
    private confirmation: ConfirmationService,
    private toaster: ToasterService,
    private applicationStatus: ApplicationStatusAppserviceService
  ) {}
  ngOnInit(): void {
    this.currentTab = 0; // Current tab is set to be the first tab (0)
    this.personalDetails = true;
    this.CheckApplicationOpen();
    this.initializeQualification();

    //this.showTab(this.currentTab); // Display the current tab
  }
  CheckApplicationOpen() {
    this.applicationStatus
      .getApplicationStatusByApplcationname('APPLICATION FOR HS AND HSS SCHOOL TEACHER')
      .subscribe(result => {
        this.isApplicationOpen = result.isOpen;
      });
  }
  //   showTab(n:number) {
  //     // This function will display the specified tab of the form...
  //     var x = document.getElementsByClassName("tab");
  //     x[n].style.display = "block";
  //     //... and fix the Previous/Next buttons:
  //     if (n == 0) {
  //         document.getElementById("prevBtn").style.display = "none";
  //     } else {
  //         document.getElementById("prevBtn").style.display = "inline";
  //     }
  //     if (n == (x.length - 1)) {
  //         document.getElementById("nextBtn").innerHTML = "Submit";
  //     } else {
  //         document.getElementById("nextBtn").innerHTML = "Next";
  //     }
  //     //... and run a function that will display the correct step indicator:
  //     this.fixStepIndicator(n)
  // }
  // fixStepIndicator(n) {
  //   // This function removes the "active" class of all steps...
  //   var i, x = document.getElementsByClassName("step");
  //   for (i = 0; i < x.length; i++) {
  //       x[i].className = x[i].className.replace(" active", "");
  //   }
  //   //... and adds the "active" class on the current step:
  //   x[n].className += " active";
  // }
  nextPrev(n: number) {
    //(this.currentTab !==0 || n !== -1) ?this.currentTab+n:0;
    if (this.validate() == false) return;
    this.currentTab = this.currentTab + n;
    if (this.currentTab == 0) {
      this.personalDetails = true;
      this.qualification = false;
      this.experience = false;
      this.displaydetails = false;
    } else if (this.currentTab == 1) {
      this.personalDetails = false;
      this.qualification = true;
      this.experience = false;
      this.displaydetails = false;
    } else if (this.currentTab == 2) {
      this.personalDetails = false;
      this.qualification = false;
      this.experience = true;
      this.displaydetails = false;
    } else if (this.currentTab == 3) {
      this.personalDetails = false;
      this.qualification = false;
      this.experience = false;
      this.displaydetails = true;
    }
  }
  InValidPost: boolean = false;
  InValidPostName: boolean = false;
  InvalidName: boolean = false;
  InValidGender: boolean = false;
  InValiddateOfBirth: boolean = false;
  InValidhouseName: boolean = false;
  InvalidfathersName: boolean = false;
  InValidpostOffice: boolean = false;
  InValidpin: boolean = false;
  InValiddistrict: boolean = false;
  Invalidstate: boolean = false;
  InValidcountry: boolean = false;
  InValidnativePlace: boolean = false;
  InValidresidentPlace: boolean = false;
  InvalidmobileNumber: boolean = false;
  InValidwhatsAppNumber: boolean = false;
  InValidemail: boolean = false;
  InValidPhoto: boolean = false;
  validate() {
    if (this.currentTab == 0) {
      if (
        this.createorEditApplication.isHighSchool == undefined ||
        this.createorEditApplication.isHighSchool == null
      ) {
        this.InValidPost = true;
        return false;
      } else if (
        this.createorEditApplication.appliedPost == '' ||
        this.createorEditApplication.appliedPost == undefined ||
        this.createorEditApplication.appliedPost == null
      ) {
        this.InValidPostName = true;
        return false;
      } else if (
        this.createorEditApplication.name == '' ||
        this.createorEditApplication.name == undefined ||
        this.createorEditApplication.name == null
      ) {
        this.InvalidName = true;
        return false;
      } else if (
        this.createorEditApplication.gender == '' ||
        this.createorEditApplication.gender == undefined ||
        this.createorEditApplication.gender == null
      ) {
        this.InValidGender = true;
        return false;
      } else if (
        this.createorEditApplication.dateOfBirth == '' ||
        this.createorEditApplication.dateOfBirth == undefined ||
        this.createorEditApplication.dateOfBirth == null
      ) {
        this.InValiddateOfBirth = true;
        return false;
      } else if (
        this.createorEditApplication.fathersName == '' ||
        this.createorEditApplication.fathersName == undefined ||
        this.createorEditApplication.fathersName == null
      ) {
        this.InvalidfathersName = true;
        return false;
      } else if (
        this.createorEditApplication.houseName == '' ||
        this.createorEditApplication.houseName == undefined ||
        this.createorEditApplication.houseName == null
      ) {
        this.InValidhouseName = true;
        return false;
      } else if (
        this.createorEditApplication.postOffice == '' ||
        this.createorEditApplication.postOffice == undefined ||
        this.createorEditApplication.postOffice == null
      ) {
        this.InValidpostOffice = true;
        return false;
      } else if (
        this.createorEditApplication.pin == '' ||
        this.createorEditApplication.pin == undefined ||
        this.createorEditApplication.pin == null
      ) {
        this.InValidpin = true;
        return false;
      } else if (
        this.createorEditApplication.district == '' ||
        this.createorEditApplication.district == undefined ||
        this.createorEditApplication.district == null
      ) {
        this.InValiddistrict = true;
        return false;
      } else if (
        this.createorEditApplication.state == '' ||
        this.createorEditApplication.state == undefined ||
        this.createorEditApplication.state == null
      ) {
        this.Invalidstate = true;
        return false;
      } else if (
        this.createorEditApplication.country == '' ||
        this.createorEditApplication.country == undefined ||
        this.createorEditApplication.country == null
      ) {
        this.InValidcountry = true;
        return false;
      } else if (
        this.createorEditApplication.nativePlace == '' ||
        this.createorEditApplication.nativePlace == undefined ||
        this.createorEditApplication.nativePlace == null
      ) {
        this.InValidnativePlace = true;
        return false;
      } else if (
        this.createorEditApplication.residentPlace == '' ||
        this.createorEditApplication.residentPlace == undefined ||
        this.createorEditApplication.residentPlace == null
      ) {
        this.InValidresidentPlace = true;
        return false;
      } else if (
        this.createorEditApplication.mobileNumber == '' ||
        this.createorEditApplication.mobileNumber == undefined ||
        this.createorEditApplication.mobileNumber == null
      ) {
        this.InvalidmobileNumber = true;
        return false;
      } else if (
        this.createorEditApplication.whatsAppNumber == '' ||
        this.createorEditApplication.whatsAppNumber == undefined ||
        this.createorEditApplication.whatsAppNumber == null
      ) {
        this.InValidwhatsAppNumber = true;
        return false;
      } else if (
        this.createorEditApplication.email == '' ||
        this.createorEditApplication.email == undefined ||
        this.createorEditApplication.email == null
      ) {
        this.InValidemail = true;
        return false;
      } else if (
        this.cardImageBase64 == '' ||
        this.cardImageBase64 == undefined ||
        this.cardImageBase64 == null
      ) {
        this.InValidPhoto = true;
        return false;
      } else {
        return true;
      }
    }
    if (this.currentTab == 1) {
      if (this.quatificationDtos.length == 0) {
        this.toaster.error('Please add qualification');
        return false;
      } else {
        for (var i = 0; i < this.quatificationDtos.length; i++) {
          debugger;
          if (
            this.quatificationDtos[i].qualifaication == null ||
            this.quatificationDtos[i].qualifaication == undefined ||
            this.quatificationDtos[i].qualifaication == '' ||
            this.quatificationDtos[i].boardOrUniversity == null ||
            this.quatificationDtos[i].boardOrUniversity == undefined ||
            this.quatificationDtos[i].boardOrUniversity == '' ||
            this.quatificationDtos[i].percentageMark == null ||
            this.quatificationDtos[i].percentageMark == undefined
          ) {
            this.toaster.error(
              'Please add all details at ' + (i + 1) + 'th row of eduactional qualification.'
            );
            return false;
          }
          if (this.quatificationDtos[i].percentageMark <= 0) {
            this.toaster.error("Precentage of mark can't be less than zero.");
            return false;
          }
          if (this.quatificationDtos[i].percentageMark > 100) {
            this.toaster.error("Precentage of mark can't be grater than 100.");
            return false;
          }
        }
      }
      if (this.additionalQualificationCheckBox) {
        for (var i = 0; i < this.additionalquatificationDtos.length; i++) {
          if (
            this.additionalquatificationDtos[i].qualifaication == null ||
            this.additionalquatificationDtos[i].qualifaication == undefined ||
            this.additionalquatificationDtos[i].qualifaication == '' ||
            this.additionalquatificationDtos[i].boardOrUniversity == null ||
            this.additionalquatificationDtos[i].boardOrUniversity == undefined ||
            this.additionalquatificationDtos[i].boardOrUniversity == '' ||
            this.additionalquatificationDtos[i].percentageMark == null ||
            this.additionalquatificationDtos[i].percentageMark == undefined
          ) {
            this.toaster.error(
              'Please add all details at ' +
                (i + 1) +
                'th row of additional education qualification'
            );
            return false;
          }
          if (this.additionalquatificationDtos[i].percentageMark <= 0) {
            this.toaster.error('Precentage of mark can not be zero.');
            return false;
          }
          if (this.additionalquatificationDtos[i].percentageMark > 100) {
            this.toaster.error('Precentage of mark can not be grater than 100.');
            return false;
          }
        }
      } else {
        return true;
      }
    }
    if (this.currentTab == 2) {
      if (this.experienceCheckBox) {
        for (var i = 0; i < this.experienceDtos.length; i++) {
          if (
            this.experienceDtos[i].designation == null ||
            this.experienceDtos[i].designation == undefined ||
            this.experienceDtos[i].designation == '' ||
            this.experienceDtos[i].nameOfInstitution == null ||
            this.experienceDtos[i].nameOfInstitution == undefined ||
            this.experienceDtos[i].nameOfInstitution == '' ||
            this.experienceDtos[i].durationFrom == null ||
            this.experienceDtos[i].durationFrom == undefined ||
            this.experienceDtos[i].durationFrom == undefined ||
            this.experienceDtos[i].durationTo == null ||
            this.experienceDtos[i].durationTo == undefined ||
            this.experienceDtos[i].durationTo == undefined ||
            this.experienceDtos[i].govtOrPrivate == null ||
            this.experienceDtos[i].govtOrPrivate == undefined ||
            this.experienceDtos[i].govtOrPrivate == undefined
          ) {
            this.toaster.error('Please add experience details at ' + (i + 1) + 'th row');
            return false;
          }
        }
      } else {
        return true;
      }
    }
  }
  issaving: boolean = false;
  Save() {
    this.issaving = true;
    if (this.quatificationDtos.length == 0) return;
    else if (this.quatificationDtos.length == 1 && this.quatificationDtos[0].qualifaication == '')
      return;
    // this.createorEditApplication.additionalQualifications = this.additionalquatificationDtos;
    // this.createorEditApplication.qualifications = this.quatificationDtos;
    // this.createorEditApplication.experiences = this.experienceDtos;
    this.createorEditApplication.image = this.cardImageBase64;
    this.createorEditApplication.qualifications = new Array<QualificationDto>();
    this.createorEditApplication.additionalQualifications = new Array<AdditionalQualificationDto>();
    this.createorEditApplication.experiences = new Array<ExperienceDto>();
    this.quatificationDtos.forEach(v => {
      this.createorEditApplication.qualifications.push({
        qualifaication: v.qualifaication,
        boardOrUniversity: v.boardOrUniversity,
        percentageMark: v.percentageMark,
      });
    });
    this.additionalquatificationDtos.forEach(v => {
      this.createorEditApplication.additionalQualifications.push({
        qualifaication: v.qualifaication,
        boardOrUniversity: v.boardOrUniversity,
        percentageMark: v.percentageMark,
      });
    });
    this.experienceDtos.forEach(v => {
      this.createorEditApplication.experiences.push({
        designation: v.designation,
        nameOfInstitution: v.nameOfInstitution,
        govtOrPrivate: v.govtOrPrivate,
        duration: v.duration,
        durationFrom: v.durationFrom,
        durationTo: v.durationTo,
      });
    });
    this.applicatioService
      .createNewApplicationByCreateOrEditApplication(this.createorEditApplication)
      .subscribe(result => {
        this.issaving = false;
        this.regNo = result;
        this.isSucess = true;
      });
  }
  regNo: number;
  login() {
    this.authService.navigateToLogin();
  }

  //qualification
  initializeQualification() {
    this.quatificationDtos.push({
      id: null,
      qualifaication: null,
      boardOrUniversity: null,
      percentageMark: null,
      applicationId: null,
    });
  }
  deleteQualification(Item: QualificationDto, index) {
    if (index == 0 && this.quatificationDtos.length == 1) {
      //this.clearLine(0);
      //this.notify.warn("Could not delete first row");
      return;
    }
    this.quatificationDtos.splice(index, 1);
    return 1;
  }
  addQulaification() {
    this.initializeQualification();
  }

  //additional qualification
  initializeAdditionalQualification() {
    this.additionalquatificationDtos.push({
      id: null,
      qualifaication: null,
      boardOrUniversity: null,
      percentageMark: null,
      applicationId: null,
    });
  }
  deleteAdditionalQualification(Item: AdditionalQualificationDto, index) {
    this.additionalquatificationDtos.splice(index, 1);
    return 1;
  }
  addAdditionalQulaification() {
    this.initializeAdditionalQualification();
  }

  //experience
  initializeExperience() {
    this.experienceDtos.push({
      id: null,
      designation: null,
      nameOfInstitution: null,
      govtOrPrivate: null,
      duration: null,
      durationFrom: null,
      durationTo: null,
    });
  }
  deleteinitializeExperience(Item: ExperienceDto, index) {
    if (index == 0 && this.experienceDtos.length == 1) {
      //this.clearLine(0);
      //this.notify.warn("Could not delete first row");
      return;
    }
    this.experienceDtos.splice(index, 1);
    return 1;
  }
  addinitializeExperience() {
    this.initializeExperience();
  }
  imageError: string;
  isImageSaved: boolean;
  cardImageBase64: string;
  @ViewChild('fileInput') fileInput: ElementRef;
  fileChangeEvent(fileInput: any) {
    this.imageError = null;
    if (fileInput.target.files && fileInput.target.files[0]) {
      // Size Filter Bytes
      const max_size = 204800;
      const allowed_types = ['image/png', 'image/jpeg'];
      const max_height = 15200;
      const max_width = 25600;

      if (fileInput.target.files[0].size > max_size) {
        this.imageError = 'Maximum size allowed is 200 KB';
        this.toaster.error('Maximum size allowed is 200 KB');
        this.fileInput.nativeElement.value = '';
        return false;
      }

      if (
        fileInput.target.files[0].type != allowed_types[0] &&
        fileInput.target.files[0].type != allowed_types[1]
      ) {
        this.toaster.error('Only Images are allowed ( JEPG | PNG )');
        this.imageError = 'Only Images are allowed ( JEPG | PNG )';
        this.fileInput.nativeElement.value = '';
        return false;
      }
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          const img_height = rs.currentTarget['height'];
          const img_width = rs.currentTarget['width'];

          console.log(img_height, img_width);

          if (img_height > max_height && img_width > max_width) {
            this.imageError = 'Maximum dimentions allowed ' + max_height + '*' + max_width + 'px';
            return false;
          } else {
            const imgBase64Path = e.target.result;
            this.cardImageBase64 = imgBase64Path;
            this.isImageSaved = true;
            // this.previewImagePath = imgBase64Path;
          }
        };
      };

      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }
  dateofBirth = {} as DateOfBirth;
  findAge() {
    this.dateofBirth.dateofBirth = this.createorEditApplication.dateOfBirth;
    this.applicatioService.findAgeByDateofbirth(this.dateofBirth).subscribe(result => {
      this.createorEditApplication.age = result;
    });
  }
  post: string[] = {} as string[];
  disableInputs: boolean = false;
  enableKtet: boolean = false;
  showPost: boolean = false;
  setAppliedPost() {
    this.createorEditApplication.appliedPost = null;
    this.showPost = true;
    this.disableCheckbox = false;
    if (this.isHighSchool == true) {
      this.disableInputs = true;
      this.enableKtet = true;
      this.createorEditApplication.isHighSchool = true;
      this.post = ['ENGLISH(RESERVED FOR DIFFERENTLY ABLED CANDIDATES)', 'HINDI', 'SOCIAL SCIENCE'];
    } else {
      this.createorEditApplication.isHighSchool = false;
      this.post = ['ENGLISH'];
      this.disableInputs = false;
      this.enableKtet = false;
    }
  }
  checkOnlyHandicapped() {
    if (
      this.createorEditApplication.isHighSchool == true &&
      this.createorEditApplication.appliedPost ==
        'ENGLISH(RESERVED FOR DIFFERENTLY ABLED CANDIDATES)'
    ) {
      this.toaster.warn('Highschool english teacher post is allotted for differently abled.');
    }
  }
  disableCheckbox: boolean = false;
  checkValue(value: boolean) {
    if (value) {
      //this.disableCheckbox = true;
      this.disableInputs = false;
    } else {
      this.disableInputs = true;
    }
  }
  showExperience: boolean = false;
  experienceCheckBox: boolean = false;
  chechExperience(value: boolean) {
    if (value) {
      this.showExperience = true;
      //this.experienceCheckBox = true;
      this.initializeExperience();
    } else {
      this.showExperience = false;
      this.additionalquatificationDtos = new Array<AdditionalQualificationDto>();
      // this.experienceCheckBox = true;
    }
  }
  showAdditionalQualification: boolean = false;
  additionalQualificationCheckBox: boolean = false;
  checkAdditionalQualification(value: boolean) {
    if (value) {
      this.showAdditionalQualification = true;
      //this.additionalQualificationCheckBox = true;
      this.initializeAdditionalQualification();
    } else {
      this.showAdditionalQualification = false;
      //this.additionalQualificationCheckBox = false;
      this.additionalquatificationDtos = new Array<AdditionalQualificationDto>();
    }
  }
}
