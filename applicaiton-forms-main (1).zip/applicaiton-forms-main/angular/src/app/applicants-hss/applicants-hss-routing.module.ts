import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplicationLayoutComponent } from '@abp/ng.theme.basic';
import { ApplicantsHss } from './applicants-hss.component';

const routes: Routes = [{ path: '', component: ApplicantsHss }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ApplicantHssRoutingModule {}
