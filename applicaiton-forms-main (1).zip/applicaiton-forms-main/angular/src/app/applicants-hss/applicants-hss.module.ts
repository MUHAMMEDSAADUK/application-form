import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../shared/shared.module';
import { ApplicantHssRoutingModule } from './applicants-hss-routing.module';
import { ApplicantsHss } from './applicants-hss.component';



@NgModule({
  declarations: [ApplicantsHss],
  imports: [SharedModule, ApplicantHssRoutingModule,NgSelectModule],
})
export class ApplicantsHssModule {}
  