import { Component, OnInit } from '@angular/core';
import { CreateOrEditApplicationDto, GetAllApplicationFormDto } from '@proxy/application-forms';
import { ApplicationFormService } from '@proxy/ionob/applicatios-forms';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';

@Component({
  selector: 'app-applicants-detail',
  templateUrl: './applicants-detail.component.html',
  styleUrls: ['./applicants-detail.component.scss'],
})
export class ApplicantsDetailComponent implements OnInit {
  modalisopen: boolean = false;

  saving = false;
  CreateOrEditApplicationDto: CreateOrEditApplicationDto[];
  createorEditApplication: any;
  GetAllApplicationFormDto = {} as GetAllApplicationFormDto;
  constructor(
    private _applicatioService: ApplicationFormService,
    private _fileDownloadService: FileDownloadService
  ) {}

  ngOnInit(): void {
   this.GetAllApplicationFormDto
   this.GetAllDetails();
  }
    
  exportToExcel(): void {
    this._applicatioService
      .getApplicationReportToExcel()
      //.pipe(finalize(() => { this.saving = false; }))
      .subscribe(result => {
        this._fileDownloadService.downloadTempFile(result);
      });
  }

  viewDoc(data) {
    this.createorEditApplication = data;
    console.log(data, 'on view');
    this.modalisopen = true;
  }

  GetAllDetails(){
    this._applicatioService.getAllByInput(this.GetAllApplicationFormDto).subscribe(result => {
      this.CreateOrEditApplicationDto = result;
      console.log(result, 'Result');
    });
}

}
