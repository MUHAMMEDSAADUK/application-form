import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicantsDetailComponent } from './applicants-detail.component';

const routes: Routes = [
  { path: '', component: ApplicantsDetailComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApplicantsDetailRoutingModule { }
