import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicantsDetailRoutingModule } from './applicants-detail-routing.module';
import { ApplicantsDetailComponent } from './applicants-detail.component';
import { SharedModule } from '../shared/shared.module';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';


@NgModule({
  declarations: [
    ApplicantsDetailComponent
  ],
  imports: [
    CommonModule,
    ApplicantsDetailRoutingModule,
    SharedModule,
  ],
  providers: [FileDownloadService]
})
export class ApplicantsDetailModule { }
