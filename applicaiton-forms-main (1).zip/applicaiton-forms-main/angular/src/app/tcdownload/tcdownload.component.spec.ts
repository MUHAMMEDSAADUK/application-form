import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TcdownloadComponent } from './tcdownload.component';

describe('TcdownloadComponent', () => {
  let component: TcdownloadComponent;
  let fixture: ComponentFixture<TcdownloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TcdownloadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TcdownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
