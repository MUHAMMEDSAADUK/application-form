import { Component, OnInit } from '@angular/core';
import { CreateorEditTcForm } from '@proxy/tc-upload-form';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';
import { TcFormApplicationService } from '@proxy/tc-upload-form';
import { stringify } from 'querystring';
import { ToasterService } from '@abp/ng.theme.shared';

@Component({
  selector: 'app-tcdownload',
  templateUrl: './tcdownload.component.html',
  styleUrls: ['./tcdownload.component.scss'],
})
export class TcdownloadComponent implements OnInit {
  createorEditTcForm = {} as CreateorEditTcForm;
  file: File;
  //tcnumber as string
  tcnumber: string = '';
  constructor(
    private uploadService: FileDownloadService,
    private toster: ToasterService,
    private tcFormService: TcFormApplicationService
  ) {}

  Save() {}

  ngOnInit(): void {}

  download() {
    if (this.tcnumber == null || this.tcnumber == '') {
      this.toster.error('Please enter tc number');
      return;
    } else {
      this.tcFormService.checkFileExistByTcNumber(this.tcnumber).subscribe(result => {
        if (result) {
          this.uploadService.downloadTc(this.tcnumber + '.pdf');
        } else {
          this.toster.error("Tc doen't exist");
          return;
        }
      });
    }

    // if(this.tcnumber == null || this.tcnumber == ""){
    //   this.toster.error("Please enter tc number");
    //   return;
    // }
    // //  var filename = input.TCNumber + extention;
    // else{
    // this.uploadService.downloadTc(this.tcnumber+".pdf");
    // }
  }
}
