import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplicationLayoutComponent } from '@abp/ng.theme.basic';
import { TcdownloadComponent } from './tcdownload.component';


const routes: Routes = [{ path: '', component: TcdownloadComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TcdownloadRoutingModule {}
