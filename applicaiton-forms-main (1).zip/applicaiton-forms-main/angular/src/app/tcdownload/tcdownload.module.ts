import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FileDownloadService } from '../shared/downloadFileService/file-download.service';
import { SharedModule } from '../shared/shared.module';
import { TcdownloadRoutingModule } from './tcdownload-routing.module';
import { TcdownloadComponent } from './tcdownload.component';


@NgModule({
  declarations: [TcdownloadComponent],
  imports: [SharedModule, TcdownloadRoutingModule,NgSelectModule],
  providers:[FileDownloadService]
})


export class TcdownloadModule {}