﻿using ionob.ApplicatioForms.TcUploadForm;
using ioNob.ApplicatioForms.DataExporting;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Auditing;
using Volo.Abp.Caching;

namespace ionob.ApplicatioForms.Controllers
{
    public class FileController : AbpController
    {
        private readonly IDistributedCache<TempFileInfo> _cache;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IHttpContextAccessor _hostContextAccessor;
        private readonly ITcFormApplication _tcFormApplication;

        public FileController(
            IDistributedCache<TempFileInfo> cache,
            IWebHostEnvironment webHostEnvironment,
            IHttpContextAccessor hostContextAccessor,
            ITcFormApplication tcFormApplication
            )
        {
            _cache = cache;
            _webHostEnvironment = webHostEnvironment;
            _hostContextAccessor = hostContextAccessor;
            _tcFormApplication = tcFormApplication;
        }
        [DisableAuditing]
        //[HttpGet]
        public ActionResult DownloadTempFile(FileDto file)
        {
            try
            {
                var fileBytes = _cache.Get(file.FileToken);

                //var fileBytes = _tempFileCacheManager.GetFile(file.FileToken);
                if (fileBytes == null)
                {
                    throw new UserFriendlyException("RequestedFileDoesNotExists");
                }

                return File(fileBytes.File, file.FileType);
            }
            catch (Exception e)
            {
                throw new UserFriendlyException(e.Message);
            }
        }
        //[HttpPost]
        //public async void UploadTcDetails(CreateorEditTcForm input,IFormFile file)
        //{

        //    try
        //    {
        //        var extention = System.IO.Path.GetExtension(file.FileName);
        //        var filename = input.TCNumber + extention;

        //        var path = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", filename);
        //        using (var fileStream = new FileStream(path,FileMode.Create))
        //        {
        //            file.CopyTo(fileStream);
        //        }
        //        input.TCAttchement = path;
        //        await _tcFormApplication.UploadTc(input);
        //    }
        //    catch(Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }

    
        //}

        public ActionResult DownloadTc(string filename)
        {
            try
            {

                var path = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", filename);
                byte[] bytes = System.IO.File.ReadAllBytes(path);
                if (bytes == null)
                {
                    throw new UserFriendlyException("RequestedFileDoesNotExists");
              

                }

                return File(bytes, "application/octet-stream", filename);
            }
            catch (Exception e)
            {
                throw new UserFriendlyException(e.Message);
            }
        }
      

    }
}
