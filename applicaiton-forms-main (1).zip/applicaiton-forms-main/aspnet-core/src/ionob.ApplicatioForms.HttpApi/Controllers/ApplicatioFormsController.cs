﻿using ionob.ApplicatioForms.Localization;
using Volo.Abp.AspNetCore.Mvc;

namespace ionob.ApplicatioForms.Controllers;

/* Inherit your controllers from this class.
 */
public abstract class ApplicatioFormsController : AbpControllerBase
{
    protected ApplicatioFormsController()
    {
        LocalizationResource = typeof(ApplicatioFormsResource);
    }
}
