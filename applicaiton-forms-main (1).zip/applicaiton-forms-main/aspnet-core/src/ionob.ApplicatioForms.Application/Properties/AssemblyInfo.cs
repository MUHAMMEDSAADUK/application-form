﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ionob.ApplicatioForms.Application.Tests")]
