﻿using ionob.ApplicatioForms.TcuploadForm;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;

namespace ionob.ApplicatioForms.TcUploadForm
{
    public class TcFormApplication : ApplicationService, ITcFormApplication
    {
        private readonly IRepository<TcForm, long> _repositoryTcForm;
        private readonly IHttpContextAccessor _httpContext;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public TcFormApplication(IRepository<TcForm,long> repositoryTcForm, 
            IHttpContextAccessor httpContext,
            IWebHostEnvironment webHostEnvironment)
        {
            _repositoryTcForm = repositoryTcForm;
            _httpContext = httpContext;
            _webHostEnvironment = webHostEnvironment;
        }

        //public async Task UploadTc(CreateorEditTcForm input)
        //{
        //    var details = ObjectMapper.Map<CreateorEditTcForm,TcForm>(input);
        //    await _repositoryTcForm.InsertAsync(details);
        //}
        public async Task<bool> CheckFileExist(string TcNumber)
        {
            var result = await _repositoryTcForm.GetListAsync(x => x.TCNumber == TcNumber && x.TCAttchement != null);
            if (result == null || result.Count <=0)
            {
                return false;
            }
            else return true;
        }

        //Get list View from Database(TcForm)
        public async Task<List<CreateorEditTcForm>> GetAll()
        {
            return ObjectMapper.Map<List<TcForm>, List<CreateorEditTcForm>>(await _repositoryTcForm.GetListAsync());
        }
        //Create 
        public async Task<CreateorEditTcForm> TcFormCreateAsync(CreateorEditTcForm input)
        {
            var fileExtention = GetFileExtension(input.Base64string);
            if (fileExtention  != "pdf")
            {
                throw new UserFriendlyException("Only pdf files are allowed");
            }
            else{
                var filename = input.TCNumber + ".pdf";
                var path = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", filename);
                byte[] imageBytes = Convert.FromBase64String(input.Base64string);
                File.WriteAllBytes(path, imageBytes);
                input.TCAttchement = path;

                bool TcExist = _repositoryTcForm.AnyAsync(s => s.TCNumber.ToLower() == input.TCNumber.ToLower()).Result;
                if (TcExist)
                {
                    throw new UserFriendlyException("Tc Number Already Exist");
                }

                var tcForm = ObjectMapper.Map<CreateorEditTcForm, TcForm>(input);
                var createdtcForm = await _repositoryTcForm.InsertAsync(tcForm);
                return ObjectMapper.Map<TcForm, CreateorEditTcForm>(createdtcForm);
            }

        }
        public async Task GetForEdit(CreateorEditTcForm input)
        { 
        
        
        }

            //update
            public async Task<bool> TcFormUpdateAsync(CreateorEditTcForm input)
        {
            try
            {
                if (System.IO.File.Exists(input.TCAttchement))
                {
                    System.IO.File.Delete(input.TCAttchement);
                }

                //var extention = System.IO.Path.GetExtension(input.File.FileName);
                var filename = input.TCNumber + ".pdf";

                var path = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", filename);

                byte[] imageBytes = Convert.FromBase64String(input.Base64string);

                File.WriteAllBytes(path, imageBytes);
                
                input.TCAttchement = path;

                var updateDetails = ObjectMapper.Map<CreateorEditTcForm, TcForm>(input);
                var createdTodo = await _repositoryTcForm.UpdateAsync(updateDetails);
                return true;

            }catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        //delete

        public async Task<bool> TcFormDeleteAsync(string TcNumber)
        {
            var todo = await _repositoryTcForm.FirstOrDefaultAsync(x => x.TCNumber == TcNumber && x.TCAttchement != null);
            if (todo != null)
            {
                await _repositoryTcForm.DeleteAsync(todo);
                return true;
            }
            return false;
        }

        public static string GetFileExtension(string base64String)
        {
            var data = base64String.Substring(0, 5);

            switch (data.ToUpper())
            {
                case "IVBOR":
                    return "png";
                case "/9J/4":
                    return "jpg";
                case "AAAAF":
                    return "mp4";
                case "JVBER":
                    return "pdf";
                case "AAABA":
                    return "ico";
                case "UMFYI":
                    return "rar";
                case "E1XYD":
                    return "rtf";
                case "U1PKC":
                    return "txt";
                case "MQOWM":
                case "77U/M":
                    return "srt";
                default:
                    return string.Empty;
            }
        } 

    }
}
