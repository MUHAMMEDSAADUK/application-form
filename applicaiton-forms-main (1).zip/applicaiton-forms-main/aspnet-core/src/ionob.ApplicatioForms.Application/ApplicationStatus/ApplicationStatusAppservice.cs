﻿using ionob.ApplicatioForms.ApplicationForm;
using ionob.ApplicatioForms.ApplicationForms;
using ionob.ApplicatioForms.ApplicationStatus.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;

namespace ionob.ApplicatioForms.ApplicationStatus
{
    public class ApplicationStatusAppservice : ApplicationService, IApplicationStatusAppservice
    {
        private readonly IRepository<ApplicationOpenOrClosed, int> _applicationStatusRepository;

        public ApplicationStatusAppservice(IRepository<ApplicationOpenOrClosed,int> applicationStatusRepository)
        {
            _applicationStatusRepository = applicationStatusRepository;
        }

        public async Task<GetApplicationStatusDto> GetApplicationStatus(string applcationname)
        {
            try
            {
                return ObjectMapper.Map<ApplicationOpenOrClosed, GetApplicationStatusDto>(await _applicationStatusRepository.SingleAsync(x => x.ApplicationName == applcationname));
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<GetApplicationStatusDto> SetApplicationStatus(SetApplicationStatusDto input)
        {
            try
            {
                return new GetApplicationStatusDto() { Id=1 ,ApplicationName = "APPLICATION FOR HS AND HSS SCHOOL TEACHER" };


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
