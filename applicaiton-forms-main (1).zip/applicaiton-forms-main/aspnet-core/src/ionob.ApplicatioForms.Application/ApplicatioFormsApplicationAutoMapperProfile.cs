﻿using AutoMapper;
using ionob.ApplicatioForms.ApplicationForm;
using ionob.ApplicatioForms.ApplicationForms;
using ionob.ApplicatioForms.ApplicationStatus;
using ionob.ApplicatioForms.ApplicationStatus.Dto;
using ionob.ApplicatioForms.TcuploadForm;
using ionob.ApplicatioForms.TcUploadForm;

namespace ionob.ApplicatioForms;

public class ApplicatioFormsApplicationAutoMapperProfile : Profile
{
    public ApplicatioFormsApplicationAutoMapperProfile()
    {
        /* You can configure your AutoMapper mapping configuration here.
         * Alternatively, you can split your mapping configurations
         * into multiple profile classes for a better organization. */
        CreateMap<CreateOrEditApplicationDto, Application>()
            .ForMember(x => x.Qualifications, opt => opt.Ignore())
            .ForMember(x => x.AdditionalQualifications, opt => opt.Ignore())
            .ForMember(x => x.Experiences, opt => opt.Ignore()); ;
        CreateMap<QualificationDto, Qualification>().ReverseMap();
        CreateMap<AdditionalQualificationDto, AdditionalQualification>().ReverseMap();
        CreateMap<ExperienceDto, Experience>().ReverseMap();
        CreateMap<ApplicationOpenOrClosed,GetApplicationStatusDto>().ReverseMap();
        CreateMap<SetApplicationStatusDto,ApplicationOpenOrClosed>().ReverseMap();
        CreateMap<TcForm,CreateorEditTcForm>().ReverseMap();
        CreateMap<CreateorEditTcForm, TcForm>().ReverseMap();
    }
}
