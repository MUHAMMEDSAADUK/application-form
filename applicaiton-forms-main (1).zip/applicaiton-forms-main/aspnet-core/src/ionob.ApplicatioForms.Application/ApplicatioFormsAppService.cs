﻿using System;
using System.Collections.Generic;
using System.Text;
using ionob.ApplicatioForms.Localization;
using Volo.Abp.Application.Services;

namespace ionob.ApplicatioForms;

/* Inherit your application services from this class.
 */
public abstract class ApplicatioFormsAppService : ApplicationService
{
    protected ApplicatioFormsAppService()
    {
        LocalizationResource = typeof(ApplicatioFormsResource);
    }
}
