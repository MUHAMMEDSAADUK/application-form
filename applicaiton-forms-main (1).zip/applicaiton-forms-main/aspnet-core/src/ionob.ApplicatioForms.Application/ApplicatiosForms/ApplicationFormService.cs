﻿using ionob.ApplicatioForms.ApplicationForm;
using ionob.ApplicatioForms.ApplicationForms;
using ionob.ApplicationDetail;
using ioNob.ApplicatioForms.DataExporting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Volo.Abp.ObjectMapping;

namespace ionob.ApplicatiosForms
{
    public class ApplicationFormService : ApplicationService, IApplicationFormService
    {
        private readonly IRepository<Application, long> _applicationRepository;
        private readonly IRepository<Qualification, long> _qualificationRepository;
        private readonly IRepository<AdditionalQualification, long> _additionalQualificationRepository;
        private readonly IRepository<Experience, long> _experienceRepository;
        private readonly IApplicantExcelExporter _applicantExcelExporter;

        public ApplicationFormService(
            IRepository<Application, long> applicationRepository,
            IRepository<Qualification, long> qualificationRepository,
            IRepository<AdditionalQualification, long> additionalQualificationRepository,
            IRepository<Experience, long> experienceRepository,
            IApplicantExcelExporter applicantExcelExporter
            )
        {
            _applicationRepository = applicationRepository;
            _qualificationRepository = qualificationRepository;
            _additionalQualificationRepository = additionalQualificationRepository;
            _experienceRepository = experienceRepository;
            _applicantExcelExporter = applicantExcelExporter;
        }


        public async Task<List<GetApplicationForViewDto>> GetAll(GetAllApplicationFormDto input)
         {

            IQueryable<Application> filteredApplicant = _applicationRepository.WithDetails(x => x.Qualifications, x => x.AdditionalQualifications, x => x.Experiences)
                         .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.MobileNumber.Contains(input.Filter) || e.email.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Name), e => e.Name.ToLower().Contains(input.Name.ToLower().Trim()))
                       .WhereIf(!string.IsNullOrWhiteSpace(input.MobileNumber), e => e.MobileNumber.ToLower().Contains(input.MobileNumber.ToLower().Trim()))
                       .WhereIf(!string.IsNullOrWhiteSpace(input.email), e => e.email.ToLower().Contains(input.email.ToLower()));



            var applications = filteredApplicant.ToList();
            List<GetApplicationForViewDto> result = filteredApplicant.Select(x => new GetApplicationForViewDto
            {
                Name = x.Name,
                Image = x.Image,
                DateOfBirth = x.DateOfBirth,
                Age = x.Age,
                Gender = x.Gender,
                FathersName = x.FathersName,
                Address = x.HouseName + "," + x.PostOffice + "," + x.ResidentPlace,
                Pin = x.Pin,
                District = x.District,
                State = x.State,
                Country = x.Country,
                MobileNumber = x.MobileNumber,
                WhatsAppNumber = x.WhatsAppNumber,
                email = x.email,
                AppliedPost = x.AppliedPost,
                OtherAchievements = x.OtherAchievements,
                Qualifications = x.Qualifications.Select(s => new QualificationDto

                {
                    ApplicationId = s.ApplicationId,
                    BoardOrUniversity = s.BoardOrUniversity,
                    Id = s.Id,
                    PercentageMark = s.PercentageMark,
                    Qualifaication = s.Qualifaication,
                }).ToList(),
                AdditionalQualifications = x.AdditionalQualifications.Select(s => new AdditionalQualificationDto
                {
                    ApplicationId = s.ApplicationId,
                    BoardOrUniversity = s.BoardOrUniversity,
                    PercentageMark = s.PercentageMark,
                    Qualifaication = s.Qualifaication,
                }).ToList(),
                Experiences = x.Experiences.Select(s => new ExperienceDto
                {
                    ApplicationId = s.ApplicationId,
                    Designation = s.Designation,
                    NameOfInstitution = s.NameOfInstitution,
                    Duration = s.Duration,
                    DurationFrom = s.DurationFrom,
                    DurationTo = s.DurationTo,
                    GovtOrPrivate = s.GovtOrPrivate,
                }).ToList(),




            }).ToList();
            


            return result;
        }

        public async Task<long> CreateNewApplication(CreateOrEditApplicationDto createOrEditApplication)
        {
            try
            {
                var appliction = ObjectMapper.Map<CreateOrEditApplicationDto, Application>(createOrEditApplication);
                var insertedApplication = await _applicationRepository.InsertAsync(appliction);
                await CurrentUnitOfWork.SaveChangesAsync();
                foreach (var item in createOrEditApplication.Qualifications)
                {
                    item.ApplicationId = insertedApplication.Id;
                    var qualification = ObjectMapper.Map<QualificationDto, Qualification>(item);
                    var insertQualification = await _qualificationRepository.InsertAsync(qualification);
                }
                foreach (var item in createOrEditApplication.AdditionalQualifications)
                {
                    item.ApplicationId = insertedApplication.Id;
                    var qualification = ObjectMapper.Map<AdditionalQualificationDto, AdditionalQualification>(item);
                    var insertQualification = await _additionalQualificationRepository.InsertAsync(qualification);
                }
                foreach (var item in createOrEditApplication.Experiences)
                {
                    item.ApplicationId = insertedApplication.Id;
                    var experience = ObjectMapper.Map<ExperienceDto, Experience>(item);
                    var insertQualification = await _experienceRepository.InsertAsync(experience);
                }

                return insertedApplication.Id;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> FindAge(DateOfBirth dateofbirth)
        {
            await Task.Delay(10);
            var today = DateTime.Today;
            // Calculate the age.
            var age = today.Year - dateofbirth.DateofBirth.Year;
            // Go back to the year in which the person was born in case of a leap year
            if (dateofbirth.DateofBirth.Date > today.AddYears(-age)) age--;
            return age;
        }


        //public async Task<List<Application>> GetAll()
        //{

        //    var filteredApplication = await _applicationRepository.WithDetailsAsync(x => x.Qualifications);
        //    var list = filteredApplication.Where(x => x.Id == 100).ToList();

        //    var result = await AsyncExecuter.ToListAsync(filteredApplication);

        //    /*IQueryable<List<GetApplicationForViewDto>> Data = result.Select(x=> new GetApplicationForViewDto
        //     {

        //     }).ToList()*/

        //    return result;
        //}



        //public async Task<FileDto> GetApplicationReportToExcel()
        //{
        //    Application applications = await _applicationRepository.GetAsync();
        //    return _applicantExcelExporter.ExportToFile(applications);

        //    //return null;         
        //}



        //dury
        public async Task<FileDto> GetApplicationReportToExcel()
        {
            try
            {

                var applications = await _applicationRepository.WithDetailsAsync(x => x.Qualifications, x => x.AdditionalQualifications, x => x.Experiences);


                List<GetApplicationForViewDto> re = applications.Select(x => new GetApplicationForViewDto
                {
                    Name = x.Name,
                    Age =x.Age,
                    Gender = x.Gender,
                    FathersName = x.FathersName,
                    ResidentPlace = x.ResidentPlace,
                    Address = x.HouseName+","+x.District+","+x.State,
                    MobileNumber = x.MobileNumber,
                    WhatsAppNumber = x.WhatsAppNumber,
                    email = x.email,
                    AppliedPost = x.AppliedPost,
                    OtherAchievements = x.OtherAchievements,
                    Qualifications = x.Qualifications.Select(s=> new QualificationDto {
                        ApplicationId = s.ApplicationId,
                        BoardOrUniversity = s.BoardOrUniversity,
                        Id = s.Id,
                        PercentageMark = s.PercentageMark,
                        Qualifaication = s.Qualifaication,
                    }).ToList(),
                    AdditionalQualifications = x.AdditionalQualifications.Select(s => new AdditionalQualificationDto { 
                        ApplicationId = s.ApplicationId,
                        BoardOrUniversity = s.BoardOrUniversity,
                        PercentageMark = s.PercentageMark,
                        Qualifaication = s.Qualifaication,
                    }).ToList(),
                    Experiences = x.Experiences.Select(s => new ExperienceDto { 
                        ApplicationId = s.ApplicationId,
                        Designation = s.Designation,
                        NameOfInstitution = s.NameOfInstitution,
                        Duration = s.Duration ,
                    }).ToList(),
                    
                    


                }).ToList();

                //var newquery = (from dt in re

                //                select new Application
                //                {
                //                    Name = dt.Name,
                //                    Age = dt.Age,
                //                    Gender = dt.Gender,
                //                    DateOfBirth = dt.DateOfBirth,
                                
                //                    FathersName = dt.FathersName,


                //                }).ToList();
                /*List<GetApplicationForViewDto> excelExportDtos = ObjectMapper.Map<List<ApplicantExcelExportDto>, List<GetApplicationForViewDto>>(re);*/
                return _applicantExcelExporter.ExportToFile(re);
            }
            catch (Exception e)
            {
                throw new UserFriendlyException(e.Message);
            }
        }
    }
}



