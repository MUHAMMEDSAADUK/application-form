﻿using ionob.ApplicatioForms.DataExporting.Excel.NPOI;
using ionob.ApplicationDetail;
using ioNob.ApplicatioForms.DataExporting;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Caching;
using static System.Net.Mime.MediaTypeNames;

namespace ionob.ApplicatioForms.ApplicatiosForms
{
    public class ApplicantExcelExporter : NpoiExcelExporterBase, IApplicantExcelExporter
    {
        public ApplicantExcelExporter(IDistributedCache<TempFileInfo> cache) : base(cache)
        {
        }

        public FileDto ExportToFile(List<GetApplicationForViewDto> applications)
        {
            return CreateExcelPackage(
                "ApplicantDetails.xlsx",
                excelPackage =>
                {
                    var sheet = excelPackage.CreateSheet("ApplicantDetails");


                    AddHeader(
                        sheet,
                        "SlNo",
                        "Name",
                        "Age",
                        "Gender",
                        "FathersName",
                        "Place",
                        "Address",
                        "MobileNo",
                        "WhatsappNo",
                        "Email",
                        "AppliedPost",
                        "Other Achievements"
                        );


                    AddObjectsCustomForApplicantReport(sheet, 1, applications, applications,
                          _ =>_.State,
                          _ => _.Name,
                          _ => _.Age,
                          _ => _.Gender,
                          _ => _.FathersName,
                          _ => _.ResidentPlace,
                          _ => _.Address,
                          _ => _.MobileNumber,
                          _ => _.WhatsAppNumber,
                          _ => _.email,
                          _ => _.AppliedPost,
                          _ => _.OtherAchievements);

                });
            
        }
        protected static void AddObjectsCustomForApplicantReport<T>(ISheet sheet, int startRowIndex, IList<T> items, List<GetApplicationForViewDto> listItems, params Func<T, object>[] propertySelectors)
        {
            if(items.Count == 0)
            {
                return;
            }
            int rowIndex = startRowIndex+ 1;

            for(int i = 1; i <= items.Count; i++)
            {
                var row = sheet.CreateRow(rowIndex);

                for (int j = 0; j < propertySelectors.Length; j++)
                {
                    
                    var cell = row.CreateCell(j);
                    if (j == 0)
                    {
                        cell.SetCellValue(i.ToString());
                    }
                    else
                    {
                        var value = propertySelectors[j](items[i - 1]);
                        if (value != null)
                        {
                            cell.SetCellValue(value.ToString());
                        }
                    }
                }
                rowIndex++;

                var amountCellAlignRightWithBoldStyle = sheet.Workbook.CreateCellStyle();
                amountCellAlignRightWithBoldStyle.Alignment = HorizontalAlignment.Left;

                var fontForAmount = sheet.Workbook.CreateFont();
                fontForAmount.IsBold = true;
                fontForAmount.FontHeightInPoints = 12;
                fontForAmount.FontName = "Calibri";
                amountCellAlignRightWithBoldStyle.SetFont(fontForAmount);

                var nextrow = sheet.CreateRow(rowIndex);
                var nextcell = nextrow.CreateCell(1);
                nextcell.SetCellValue("Educational Qualification");
                nextcell.CellStyle = amountCellAlignRightWithBoldStyle;

                rowIndex++;

                if (listItems[i-1].Qualifications.Count > 0)
                {
                    var qualificationrow = sheet.CreateRow(rowIndex);
                    
                       var qualificationHeader1 = qualificationrow.CreateCell(1);
                    qualificationHeader1.SetCellValue("Course");
                        var qualificationHeader2 = qualificationrow.CreateCell(2);
                    qualificationHeader2.SetCellValue("Board");
                        var qualificationHeader3 = qualificationrow.CreateCell(3);
                    qualificationHeader3.SetCellValue("Marks(%)");
                    var index = 1;
                    rowIndex++;
                    foreach (var qualifications in listItems[i-1].Qualifications)
                    {
                        var qualificationDataIndex = sheet.CreateRow(rowIndex);
                        
                            qualificationDataIndex.CreateCell(1).SetCellValue(qualifications.Qualifaication.ToString());
                            qualificationDataIndex.CreateCell(2).SetCellValue(qualifications.BoardOrUniversity.ToString());
                            qualificationDataIndex.CreateCell(3).SetCellValue(qualifications.PercentageMark.ToString());
                        rowIndex++;
                    }
                }
                var addQnextRow = sheet.CreateRow(rowIndex);
                var addQnextcell = addQnextRow.CreateCell(1);
                addQnextcell.SetCellValue("Additional Qualification");
                addQnextcell.CellStyle = amountCellAlignRightWithBoldStyle;
                rowIndex++;
                if (listItems[i-1].AdditionalQualifications.Count > 0)
                {
                    var additionalqualificationrow = sheet.CreateRow(rowIndex);

                    var qualificationHeader1 = additionalqualificationrow.CreateCell(1);
                    qualificationHeader1.SetCellValue("Course");
                    var qualificationHeader2 = additionalqualificationrow.CreateCell(2);
                    qualificationHeader2.SetCellValue("Board");
                    var qualificationHeader3 = additionalqualificationrow.CreateCell(3);
                    qualificationHeader3.SetCellValue("Marks(%)");
                    rowIndex++;
                    foreach (var qualifications in listItems[i-1].AdditionalQualifications)
                    {
                        var qualificationDataIndex = sheet.CreateRow(rowIndex);

                        qualificationDataIndex.CreateCell(1).SetCellValue(qualifications.Qualifaication.ToString());
                        qualificationDataIndex.CreateCell(2).SetCellValue(qualifications.BoardOrUniversity.ToString());
                        qualificationDataIndex.CreateCell(3).SetCellValue(qualifications.PercentageMark.ToString());
                        rowIndex++;
                    }
                }
                var ExpnextRow = sheet.CreateRow(rowIndex);
                var Expnextcell = ExpnextRow.CreateCell(1);
                Expnextcell.SetCellValue("Experience");
                Expnextcell.CellStyle = amountCellAlignRightWithBoldStyle;
                rowIndex++;
                if (listItems[i-1].Experiences.Count > 0)
                {
                    var Expericencerow = sheet.CreateRow(rowIndex);

                    var qualificationHeader1 = Expericencerow.CreateCell(1);
                    qualificationHeader1.SetCellValue("Designation");
                    var qualificationHeader2 = Expericencerow.CreateCell(2);
                    qualificationHeader2.SetCellValue("Institution");
                    var qualificationHeader3 = Expericencerow.CreateCell(3);
                    qualificationHeader3.SetCellValue("Govt/Private");
                    var qualificationHeader4 = Expericencerow.CreateCell(4);
                    qualificationHeader4.SetCellValue("Duration From");
                    var qualificationHeader5 = Expericencerow.CreateCell(5);
                    qualificationHeader5.SetCellValue("Duration To");
                    var index = 1;
                    rowIndex++;
                    foreach (var qualifications in listItems[i-1].Experiences)
                    {
                        var qualificationDataIndex = sheet.CreateRow(rowIndex);

                        qualificationDataIndex.CreateCell(1).SetCellValue(qualifications.Designation.ToString());
                        qualificationDataIndex.CreateCell(2).SetCellValue(qualifications.NameOfInstitution.ToString());
                        qualificationDataIndex.CreateCell(3).SetCellValue(qualifications.GovtOrPrivate != null ? qualifications.GovtOrPrivate.ToString() : " ");
                        qualificationDataIndex.CreateCell(4).SetCellValue(qualifications.DurationFrom.ToString());
                        qualificationDataIndex.CreateCell(5).SetCellValue(qualifications.DurationTo.ToString());
                        rowIndex++;
                    }
                }
                rowIndex++;
            }
        }
    }
}
