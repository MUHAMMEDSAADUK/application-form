﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ionob.ApplicatioForms.Migrations
{
    public partial class Primerykeychangefromguidtolong : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "Id",
                table: "AppQualifications",
                type: "bigint",
                nullable: false,
                defaultValue: 0L)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<long>(
                name: "ApplicationId",
                table: "AppQualifications",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "Id",
                table: "AppExperiences",
                type: "bigint",
                nullable: false,
                defaultValue: 0L)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<long>(
                name: "ApplicationId",
                table: "AppExperiences",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "Id",
                table: "AppApplications",
                type: "bigint",
                nullable: false,
                defaultValue: 0L)
                .Annotation("SqlServer:Identity", "100, 1");

            migrationBuilder.AddColumn<long>(
                name: "Id",
                table: "AppAdditionalQualifications",
                type: "bigint",
                nullable: false,
                defaultValue: 0L)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<long>(
                name: "ApplicationId",
                table: "AppAdditionalQualifications",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppQualifications",
                table: "AppQualifications",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppExperiences",
                table: "AppExperiences",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppApplications",
                table: "AppApplications",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_AppQualifications_ApplicationId",
                table: "AppQualifications",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_AppExperiences_ApplicationId",
                table: "AppExperiences",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_AppAdditionalQualifications_ApplicationId",
                table: "AppAdditionalQualifications",
                column: "ApplicationId");

            migrationBuilder.AddForeignKey(
                name: "FK_AppAdditionalQualifications_AppApplications_ApplicationId",
                table: "AppAdditionalQualifications",
                column: "ApplicationId",
                principalTable: "AppApplications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AppExperiences_AppApplications_ApplicationId",
                table: "AppExperiences",
                column: "ApplicationId",
                principalTable: "AppApplications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AppQualifications_AppApplications_ApplicationId",
                table: "AppQualifications",
                column: "ApplicationId",
                principalTable: "AppApplications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AppAdditionalQualifications_AppApplications_ApplicationId",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropForeignKey(
                name: "FK_AppExperiences_AppApplications_ApplicationId",
                table: "AppExperiences");

            migrationBuilder.DropForeignKey(
                name: "FK_AppQualifications_AppApplications_ApplicationId",
                table: "AppQualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppQualifications",
                table: "AppQualifications");

            migrationBuilder.DropIndex(
                name: "IX_AppQualifications_ApplicationId",
                table: "AppQualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppExperiences",
                table: "AppExperiences");

            migrationBuilder.DropIndex(
                name: "IX_AppExperiences_ApplicationId",
                table: "AppExperiences");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppApplications",
                table: "AppApplications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropIndex(
                name: "IX_AppAdditionalQualifications_ApplicationId",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AppQualifications");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "AppQualifications");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AppExperiences");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "AppExperiences");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AppApplications");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "AppAdditionalQualifications");
        }
    }
}
