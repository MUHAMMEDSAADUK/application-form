﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ionob.ApplicatioForms.Migrations
{
    public partial class Addingnewbariblesishighersecondaryandappliedpost : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AppliedPost",
                table: "ApplicationFormsAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsHighSchool",
                table: "ApplicationFormsAdditionalQualifications",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AppliedPost",
                table: "ApplicationFormsAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "IsHighSchool",
                table: "ApplicationFormsAdditionalQualifications");
        }
    }
}
