﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ionob.ApplicatioForms.Migrations
{
    public partial class TableNamechange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AdditionalQualifications_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "AdditionalQualifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Experiences_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "Experiences");

            migrationBuilder.DropForeignKey(
                name: "FK_Qualifications_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "Qualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ApplicationFormsAdditionalQualifications",
                table: "ApplicationFormsAdditionalQualifications");

            migrationBuilder.RenameTable(
                name: "ApplicationFormsAdditionalQualifications",
                newName: "AppAdditionalQualifications");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_AdditionalQualifications_AppAdditionalQualifications_ApplicationId",
                table: "AdditionalQualifications",
                column: "ApplicationId",
                principalTable: "AppAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Experiences_AppAdditionalQualifications_ApplicationId",
                table: "Experiences",
                column: "ApplicationId",
                principalTable: "AppAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Qualifications_AppAdditionalQualifications_ApplicationId",
                table: "Qualifications",
                column: "ApplicationId",
                principalTable: "AppAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AdditionalQualifications_AppAdditionalQualifications_ApplicationId",
                table: "AdditionalQualifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Experiences_AppAdditionalQualifications_ApplicationId",
                table: "Experiences");

            migrationBuilder.DropForeignKey(
                name: "FK_Qualifications_AppAdditionalQualifications_ApplicationId",
                table: "Qualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications");

            migrationBuilder.RenameTable(
                name: "AppAdditionalQualifications",
                newName: "ApplicationFormsAdditionalQualifications");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ApplicationFormsAdditionalQualifications",
                table: "ApplicationFormsAdditionalQualifications",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_AdditionalQualifications_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "AdditionalQualifications",
                column: "ApplicationId",
                principalTable: "ApplicationFormsAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Experiences_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "Experiences",
                column: "ApplicationId",
                principalTable: "ApplicationFormsAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Qualifications_ApplicationFormsAdditionalQualifications_ApplicationId",
                table: "Qualifications",
                column: "ApplicationId",
                principalTable: "ApplicationFormsAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
