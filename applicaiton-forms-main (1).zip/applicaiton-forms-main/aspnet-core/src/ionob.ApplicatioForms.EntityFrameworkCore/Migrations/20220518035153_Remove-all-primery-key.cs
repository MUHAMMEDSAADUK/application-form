﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ionob.ApplicatioForms.Migrations
{
    public partial class Removeallprimerykey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Experiences_AppAdditionalQualifications_ApplicationId",
                table: "Experiences");

            migrationBuilder.DropForeignKey(
                name: "FK_Qualifications_AppAdditionalQualifications_ApplicationId",
                table: "Qualifications");

            migrationBuilder.DropTable(
                name: "AdditionalQualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Qualifications",
                table: "Qualifications");

            migrationBuilder.DropIndex(
                name: "IX_Qualifications_ApplicationId",
                table: "Qualifications");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Experiences",
                table: "Experiences");

            migrationBuilder.DropIndex(
                name: "IX_Experiences_ApplicationId",
                table: "Experiences");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Age",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "AppliedPost",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Country",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "DateOfBirth",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "District",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "FathersName",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "HouseName",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Image",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "IsHighSchool",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "MobileNumber",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "NativePlace",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "OtherAchievements",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Pin",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "PostOffice",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "RegistrationNumber",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "ResidentPlace",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "State",
                table: "AppAdditionalQualifications");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "Qualifications");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "Qualifications");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "Experiences");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "Experiences");

            migrationBuilder.RenameTable(
                name: "Qualifications",
                newName: "AppQualifications");

            migrationBuilder.RenameTable(
                name: "Experiences",
                newName: "AppExperiences");

            migrationBuilder.RenameColumn(
                name: "email",
                table: "AppAdditionalQualifications",
                newName: "Qualifaication");

            migrationBuilder.RenameColumn(
                name: "WhatsAppNumber",
                table: "AppAdditionalQualifications",
                newName: "BoardOrUniversity");

            migrationBuilder.AddColumn<decimal>(
                name: "PercentageMark",
                table: "AppAdditionalQualifications",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "AppApplications",
                columns: table => new
                {
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Age = table.Column<int>(type: "int", nullable: true),
                    FathersName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HouseName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PostOffice = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pin = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    District = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NativePlace = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResidentPlace = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    WhatsAppNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OtherAchievements = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Image = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RegistrationNumber = table.Column<long>(type: "bigint", nullable: true),
                    AppliedPost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsHighSchool = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppApplications");

            migrationBuilder.DropColumn(
                name: "PercentageMark",
                table: "AppAdditionalQualifications");

            migrationBuilder.RenameTable(
                name: "AppQualifications",
                newName: "Qualifications");

            migrationBuilder.RenameTable(
                name: "AppExperiences",
                newName: "Experiences");

            migrationBuilder.RenameColumn(
                name: "Qualifaication",
                table: "AppAdditionalQualifications",
                newName: "email");

            migrationBuilder.RenameColumn(
                name: "BoardOrUniversity",
                table: "AppAdditionalQualifications",
                newName: "WhatsAppNumber");

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "AppAdditionalQualifications",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<int>(
                name: "Age",
                table: "AppAdditionalQualifications",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AppliedPost",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Country",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DateOfBirth",
                table: "AppAdditionalQualifications",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "District",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FathersName",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HouseName",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Image",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsHighSchool",
                table: "AppAdditionalQualifications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "MobileNumber",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NativePlace",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OtherAchievements",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Pin",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PostOffice",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "RegistrationNumber",
                table: "AppAdditionalQualifications",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ResidentPlace",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "State",
                table: "AppAdditionalQualifications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "Qualifications",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "ApplicationId",
                table: "Qualifications",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "Experiences",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "ApplicationId",
                table: "Experiences",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddPrimaryKey(
                name: "PK_AppAdditionalQualifications",
                table: "AppAdditionalQualifications",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Qualifications",
                table: "Qualifications",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Experiences",
                table: "Experiences",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "AdditionalQualifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ApplicationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    BoardOrUniversity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PercentageMark = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Qualifaication = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdditionalQualifications", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AdditionalQualifications_AppAdditionalQualifications_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "AppAdditionalQualifications",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Qualifications_ApplicationId",
                table: "Qualifications",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Experiences_ApplicationId",
                table: "Experiences",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_AdditionalQualifications_ApplicationId",
                table: "AdditionalQualifications",
                column: "ApplicationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Experiences_AppAdditionalQualifications_ApplicationId",
                table: "Experiences",
                column: "ApplicationId",
                principalTable: "AppAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Qualifications_AppAdditionalQualifications_ApplicationId",
                table: "Qualifications",
                column: "ApplicationId",
                principalTable: "AppAdditionalQualifications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
