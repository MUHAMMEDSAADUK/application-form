﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ionob.ApplicatioForms.EntityFrameworkCore.Tests")]
