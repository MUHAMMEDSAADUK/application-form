﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ionob.ApplicatioForms.Data;
using Volo.Abp.DependencyInjection;

namespace ionob.ApplicatioForms.EntityFrameworkCore;

public class EntityFrameworkCoreApplicatioFormsDbSchemaMigrator
    : IApplicatioFormsDbSchemaMigrator, ITransientDependency
{
    private readonly IServiceProvider _serviceProvider;

    public EntityFrameworkCoreApplicatioFormsDbSchemaMigrator(
        IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task MigrateAsync()
    {
        /* We intentionally resolving the ApplicatioFormsDbContext
         * from IServiceProvider (instead of directly injecting it)
         * to properly get the connection string of the current tenant in the
         * current scope.
         */

        await _serviceProvider
            .GetRequiredService<ApplicatioFormsDbContext>()
            .Database
            .MigrateAsync();
    }
}
