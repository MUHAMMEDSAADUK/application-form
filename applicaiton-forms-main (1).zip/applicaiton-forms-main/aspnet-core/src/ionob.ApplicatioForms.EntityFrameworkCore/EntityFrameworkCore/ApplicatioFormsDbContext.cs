﻿using ionob.ApplicatioForms.ApplicationForm;
using ionob.ApplicatioForms.ApplicationStatus;
using ionob.ApplicatioForms.TcuploadForm;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.AuditLogging.EntityFrameworkCore;
using Volo.Abp.BackgroundJobs.EntityFrameworkCore;
using Volo.Abp.Data;
using Volo.Abp.DependencyInjection;
using Volo.Abp.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore.Modeling;
using Volo.Abp.FeatureManagement.EntityFrameworkCore;
using Volo.Abp.Identity;
using Volo.Abp.Identity.EntityFrameworkCore;
using Volo.Abp.IdentityServer.EntityFrameworkCore;
using Volo.Abp.PermissionManagement.EntityFrameworkCore;
using Volo.Abp.SettingManagement.EntityFrameworkCore;
using Volo.Abp.TenantManagement;
using Volo.Abp.TenantManagement.EntityFrameworkCore;

namespace ionob.ApplicatioForms.EntityFrameworkCore;

[ReplaceDbContext(typeof(IIdentityDbContext))]
[ReplaceDbContext(typeof(ITenantManagementDbContext))]
[ConnectionStringName("Default")]
public class ApplicatioFormsDbContext :
    AbpDbContext<ApplicatioFormsDbContext>,
    IIdentityDbContext,
    ITenantManagementDbContext
{
    /* Add DbSet properties for your Aggregate Roots / Entities here. */

    #region Entities from the modules

    /* Notice: We only implemented IIdentityDbContext and ITenantManagementDbContext
     * and replaced them for this DbContext. This allows you to perform JOIN
     * queries for the entities of these modules over the repositories easily. You
     * typically don't need that for other modules. But, if you need, you can
     * implement the DbContext interface of the needed module and use ReplaceDbContext
     * attribute just like IIdentityDbContext and ITenantManagementDbContext.
     *
     * More info: Replacing a DbContext of a module ensures that the related module
     * uses this DbContext on runtime. Otherwise, it will use its own DbContext class.
     */

    //Identity
    public DbSet<IdentityUser> Users { get; set; }
    public DbSet<IdentityRole> Roles { get; set; }
    public DbSet<IdentityClaimType> ClaimTypes { get; set; }
    public DbSet<OrganizationUnit> OrganizationUnits { get; set; }
    public DbSet<IdentitySecurityLog> SecurityLogs { get; set; }
    public DbSet<IdentityLinkUser> LinkUsers { get; set; }

    // Tenant Management
    public DbSet<Tenant> Tenants { get; set; }
    public DbSet<TenantConnectionString> TenantConnectionStrings { get; set; }
    public DbSet<Application> Applications { get; set; }
    public DbSet<Qualification> Qualifications { get; set; }
    public DbSet<Experience> Experiences { get; set; }
    public DbSet<AdditionalQualification> AdditionalQualifications { get; set; }
    public DbSet<ApplicationOpenOrClosed> ApplicationsStatus { get; set; }
    public DbSet<TcForm> TCForms { get; set; }
    #endregion
 

    public ApplicatioFormsDbContext(DbContextOptions<ApplicatioFormsDbContext> options)
        : base(options)
    {


    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        /* Include modules to your migration db context */

        builder.ConfigurePermissionManagement();
        builder.ConfigureSettingManagement();
        builder.ConfigureBackgroundJobs();
        builder.ConfigureAuditLogging();
        builder.ConfigureIdentity();
        builder.ConfigureIdentityServer();
        builder.ConfigureFeatureManagement();
        builder.ConfigureTenantManagement();

        /* Configure your own tables/entities inside here */

        //builder.Entity<YourEntity>(b =>
        //{
        //    b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "YourEntities", ApplicatioFormsConsts.DbSchema);
        //    b.ConfigureByConvention(); //auto configure for the base class props
        //    //...
        //});
        builder.Entity<Application>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "Applications");
            b.ConfigureByConvention();
            b.Property(x => x.Id).UseIdentityColumn<long>(seed: 100, increment: 1);
            //auto configure for the base class props
        });
        builder.Entity<Qualification>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "Qualifications");
            b.ConfigureByConvention(); //auto configure for the base class props

        });
        builder.Entity<Experience>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "Experiences");
            b.ConfigureByConvention(); //auto configure for the base class props

        });
        builder.Entity<AdditionalQualification>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "AdditionalQualifications");
            b.ConfigureByConvention(); //auto configure for the base class props

        });
        builder.Entity<ApplicationOpenOrClosed>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "ApplicationStatus");
            b.ConfigureByConvention(); //auto configure for the base class props

        });
        builder.Entity<TcForm>(b =>
        {
            b.ToTable(ApplicatioFormsConsts.DbTablePrefix + "TCForms");
            b.ConfigureByConvention(); //auto configure for the base class props

        });





    }
}
