﻿using System;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace ionob.ApplicatioForms.EntityFrameworkCore;

/* This class is needed for EF Core console commands
 * (like Add-Migration and Update-Database commands) */
public class ApplicatioFormsDbContextFactory : IDesignTimeDbContextFactory<ApplicatioFormsDbContext>
{
    public ApplicatioFormsDbContext CreateDbContext(string[] args)
    {
        ApplicatioFormsEfCoreEntityExtensionMappings.Configure();

        var configuration = BuildConfiguration();

        var builder = new DbContextOptionsBuilder<ApplicatioFormsDbContext>()
            .UseSqlServer(configuration.GetConnectionString("Default"));

        return new ApplicatioFormsDbContext(builder.Options);
    }

    private static IConfigurationRoot BuildConfiguration()
    {
        var builder = new ConfigurationBuilder()
            .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "../ionob.ApplicatioForms.DbMigrator/"))
            .AddJsonFile("appsettings.json", optional: false);

        return builder.Build();
    }
}
