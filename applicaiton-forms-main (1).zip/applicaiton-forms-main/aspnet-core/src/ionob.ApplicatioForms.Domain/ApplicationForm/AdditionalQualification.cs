﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Domain.Entities;

namespace ionob.ApplicatioForms.ApplicationForm
{
    public class AdditionalQualification:Entity<long>
    {
        public string Qualifaication { get; set; }
        public string BoardOrUniversity { get; set; }
        public decimal? PercentageMark { get; set; }
        public virtual long ApplicationId { get; set; }
        public Application Application { get; set; }
    }
}
