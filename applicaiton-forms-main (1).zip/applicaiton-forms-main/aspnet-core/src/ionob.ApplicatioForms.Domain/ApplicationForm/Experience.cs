﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Domain.Entities;

namespace ionob.ApplicatioForms.ApplicationForm
{
    public class Experience : Entity<long>
    {
        public string Designation { get; set; }
        public string NameOfInstitution { get; set; }
        public string GovtOrPrivate { get; set; }
        public string Duration { get; set; }
        public virtual long ApplicationId { get; set; }
        public Application Application { get; set; }
        public DateTime? DurationFrom { get; set; }
        public DateTime? DurationTo { get; set; }
    }
}

