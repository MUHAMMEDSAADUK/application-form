﻿namespace ionob.ApplicatioForms.Settings;

public static class ApplicatioFormsSettings
{
    private const string Prefix = "ApplicatioForms";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
