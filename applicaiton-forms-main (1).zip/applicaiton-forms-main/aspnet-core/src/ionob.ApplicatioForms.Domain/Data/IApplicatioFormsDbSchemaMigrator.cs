﻿using System.Threading.Tasks;

namespace ionob.ApplicatioForms.Data;

public interface IApplicatioFormsDbSchemaMigrator
{
    Task MigrateAsync();
}
