﻿using System.Threading.Tasks;
using Volo.Abp.DependencyInjection;

namespace ionob.ApplicatioForms.Data;

/* This is used if database provider does't define
 * IApplicatioFormsDbSchemaMigrator implementation.
 */
public class NullApplicatioFormsDbSchemaMigrator : IApplicatioFormsDbSchemaMigrator, ITransientDependency
{
    public Task MigrateAsync()
    {
        return Task.CompletedTask;
    }
}
