﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ionob.ApplicatioForms.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("ionob.ApplicatioForms.TestBase")]
