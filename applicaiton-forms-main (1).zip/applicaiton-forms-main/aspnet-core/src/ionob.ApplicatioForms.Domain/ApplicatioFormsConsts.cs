﻿namespace ionob.ApplicatioForms;

public static class ApplicatioFormsConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
