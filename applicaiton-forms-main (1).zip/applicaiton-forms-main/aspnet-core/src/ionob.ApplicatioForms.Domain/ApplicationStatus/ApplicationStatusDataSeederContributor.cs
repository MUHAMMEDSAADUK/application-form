﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Data;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Domain.Repositories;

namespace ionob.ApplicatioForms.ApplicationStatus
{
    public class ApplicationStatusDataSeederContributor : IDataSeedContributor, ITransientDependency
    {
        private readonly IRepository<ApplicationOpenOrClosed, int> _applicationStatusRepo;

        public ApplicationStatusDataSeederContributor(IRepository<ApplicationOpenOrClosed,int> applicationStatusRepo)
        {
            _applicationStatusRepo = applicationStatusRepo;
        }

        public async Task SeedAsync(DataSeedContext context)
        {
            if (await _applicationStatusRepo.GetCountAsync() <= 0)
            {
                await _applicationStatusRepo.InsertAsync(new ApplicationOpenOrClosed()
                {
                    ApplicationName = "APPLICATION FOR HS AND HSS SCHOOL TEACHER",
                    isOpen = true
                });
            }
        }
    }
}
