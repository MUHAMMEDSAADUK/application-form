﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Domain.Entities;

namespace ionob.ApplicatioForms.ApplicationStatus
{
    public class ApplicationOpenOrClosed:Entity<int>
    {
        public string ApplicationName { get; set; } = "APPLICATION FOR HS AND HSS SCHOOL TEACHER";
        public bool isOpen { get; set; } = true;
    }
}
