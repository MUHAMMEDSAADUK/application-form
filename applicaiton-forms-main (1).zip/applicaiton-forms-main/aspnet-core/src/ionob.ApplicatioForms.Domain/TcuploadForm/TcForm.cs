﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Domain.Entities;

namespace ionob.ApplicatioForms.TcuploadForm
{
    public class TcForm:Entity<long>
    {
        public string Name { get; set; }
        public string TCNumber { get; set; }
        public int Class { get; set; }
        public string TCAttchement { get; set; }

    }

}
