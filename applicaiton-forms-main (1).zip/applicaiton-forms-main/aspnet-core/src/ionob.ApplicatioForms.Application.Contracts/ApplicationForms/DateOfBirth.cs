﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ionob.ApplicatioForms.ApplicationForms
{
    public class DateOfBirth
    {
        public DateTime DateofBirth { get; set; }
    }
}
