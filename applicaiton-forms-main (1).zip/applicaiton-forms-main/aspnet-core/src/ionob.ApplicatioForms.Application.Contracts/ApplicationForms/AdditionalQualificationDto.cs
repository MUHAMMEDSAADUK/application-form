﻿using System;
using System.Collections.Generic;
using System.Text;

using Volo.Abp.Application.Dtos;
namespace ionob.ApplicatioForms.ApplicationForms
{
    public class AdditionalQualificationDto : EntityDto<long?>
    {
        public string Qualifaication { get; set; }
        public string BoardOrUniversity { get; set; }
        public decimal? PercentageMark { get; set; }
        public virtual long? ApplicationId { get; set; }
    }
}
