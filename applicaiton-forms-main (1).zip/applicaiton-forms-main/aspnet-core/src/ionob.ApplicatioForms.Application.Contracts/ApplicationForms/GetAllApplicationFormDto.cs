﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ionob.ApplicatioForms.ApplicationForms
{
    public class GetAllApplicationFormDto
    {
        public string Filter { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string MobileNumber { get; set; }
        public string email { get; set; }









    }
}
