﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Services;

namespace ionob.ApplicatioForms.ApplicationForms
{
    public interface IApplicationFormService:IApplicationService
    {
        Task<long> CreateNewApplication(CreateOrEditApplicationDto createOrEditApplication);
        Task<int> FindAge(DateOfBirth dateofbirth);
    }
}
