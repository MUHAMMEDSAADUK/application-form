﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Application.Dtos;

namespace ionob.ApplicatioForms.ApplicationForms
{
    public class ExperienceDto:EntityDto<long?>
    {
        public string Designation { get; set; }
        public string NameOfInstitution { get; set; }
        public string GovtOrPrivate { get; set; }
        public string Duration { get; set; }
        public virtual long? ApplicationId { get; set; }
        public DateTime? DurationFrom { get; set; }
        public DateTime? DurationTo { get; set; }
    }
}
