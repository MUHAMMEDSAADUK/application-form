﻿using ionob.ApplicatioForms.ApplicationForms;
using System;
using System.Collections.Generic;
using System.Text;

namespace ionob.ApplicationDetail;

public class ApplicantExcelExportDto
{
    public string Name { get; set; }
    public string Gender { get; set; }
    public DateTime DateOfBirth { get; set; }
    public int? Age { get; set; }
    public string FathersName { get; set; }
    public string HouseName { get; set; }
    public string PostOffice { get; set; }
    public string Pin { get; set; }
    public string District { get; set; }
    public string State { get; set; }
    public string Country { get; set; }
    public string NativePlace { get; set; }
    public string ResidentPlace { get; set; }
    public string MobileNumber { get; set; }
    public string WhatsAppNumber { get; set; }
    public string email { get; set; }
    public string OtherAchievements { get; set; }
    public List<ExperienceDto> Experiences { get; set; }
    public List<QualificationDto> Qualifications { get; set; }
    public List<AdditionalQualificationDto> AdditionalQualifications { get; set; }
    public string Image { get; set; }
    public long? RegistrationNumber { get; set; }
    public string AppliedPost { get; set; }
    public bool IsHighSchool { get; set; }
}
