﻿using ioNob.ApplicatioForms.DataExporting;
using System;
using System.Collections.Generic;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace ionob.ApplicationDetail;

public interface IApplicantExcelExporter
{
    FileDto ExportToFile(List<GetApplicationForViewDto> input);
}
