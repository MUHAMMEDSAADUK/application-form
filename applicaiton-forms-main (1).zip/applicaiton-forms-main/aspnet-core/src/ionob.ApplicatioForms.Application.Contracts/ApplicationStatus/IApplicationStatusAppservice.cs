﻿using ionob.ApplicatioForms.ApplicationStatus.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ionob.ApplicatioForms.ApplicationStatus
{
    public interface IApplicationStatusAppservice
    {
        Task<GetApplicationStatusDto> GetApplicationStatus(string applcationname);
        Task<GetApplicationStatusDto> SetApplicationStatus(SetApplicationStatusDto input);
    }
}
