﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ionob.ApplicatioForms.ApplicationStatus.Dto
{
    public class SetApplicationStatusDto
    {
        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public bool isOpen { get; set; }
    }
}
