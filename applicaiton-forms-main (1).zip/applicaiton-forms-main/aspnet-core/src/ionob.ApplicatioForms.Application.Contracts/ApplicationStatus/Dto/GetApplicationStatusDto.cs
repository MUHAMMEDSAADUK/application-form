﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Application.Dtos;

namespace ionob.ApplicatioForms.ApplicationStatus.Dto
{
    public class GetApplicationStatusDto:EntityDto<int?>
    {
        public string ApplicationName { get; set; } 
        public bool isOpen { get; set; }
    }
}
