﻿using System;

namespace ionob.ApplicatioForms.TcUploadForm
{
    internal class FromFormAttribute : Attribute
    {
    }
}