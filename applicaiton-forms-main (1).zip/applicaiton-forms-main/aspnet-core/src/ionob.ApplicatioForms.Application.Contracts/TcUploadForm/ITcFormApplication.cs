﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Services;

namespace ionob.ApplicatioForms.TcUploadForm
{
    public interface ITcFormApplication:IApplicationService
    {
        //Task UploadTc(CreateorEditTcForm input);

        Task<bool> CheckFileExist(string TcNumber);


        Task<CreateorEditTcForm> TcFormCreateAsync(CreateorEditTcForm input);


        Task<bool> TcFormUpdateAsync(CreateorEditTcForm input);

        Task<bool> TcFormDeleteAsync(string TcNumber);
   
    }

}
