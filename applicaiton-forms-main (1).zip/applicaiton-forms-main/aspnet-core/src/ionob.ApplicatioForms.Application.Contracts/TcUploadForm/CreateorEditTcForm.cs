﻿using Volo.Abp.Application.Dtos;

namespace ionob.ApplicatioForms.TcUploadForm
{
    public class CreateorEditTcForm:EntityDto<long>
    {
        public string Name { get; set; }
        public string TCNumber { get; set; }
        public int Class { get; set; }
        public string TCAttchement { get; set; }
        public string Base64string { get; set; } 

    }
}
