﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ioNob.ApplicatioForms.DataExporting
{
    public interface IDownloadPreviewAsPdfAppService
    {
        Task<FileDto> DownloadPreviewPdfAsync(Guid transactionId);
    }
}
