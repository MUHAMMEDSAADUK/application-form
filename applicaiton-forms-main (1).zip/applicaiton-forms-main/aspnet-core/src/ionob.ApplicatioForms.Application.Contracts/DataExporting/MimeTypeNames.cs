﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ioNob.ApplicatioForms.DataExporting
{
    public static class MimeTypeNames
    {
        public const string ApplicationVndOpenxmlformatsOfficedocumentSpreadsheetmlSheet = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        public const string ApplicationPdf = "application/pdf";
    }
}
