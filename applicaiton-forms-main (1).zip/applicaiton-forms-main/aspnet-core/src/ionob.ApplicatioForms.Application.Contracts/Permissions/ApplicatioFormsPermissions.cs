﻿namespace ionob.ApplicatioForms.Permissions;

public static class ApplicatioFormsPermissions
{
    public const string GroupName = "ApplicationForms";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
    public static class ApplicantDetails
    {
        public const string Default = GroupName + ".ApplicantDetails";
        public const string Create = Default + ".Create";
        public const string Edit = Default + ".Edit";
        public const string Delete = Default + ".Delete";
    }
}
