﻿using ionob.ApplicatioForms.Localization;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Localization;
using static ionob.ApplicatioForms.Permissions.ApplicatioFormsPermissions;

namespace ionob.ApplicatioForms.Permissions;

public class ApplicatioFormsPermissionDefinitionProvider : PermissionDefinitionProvider
{
    public override void Define(IPermissionDefinitionContext context)
    {
        var myGroup = context.AddGroup(ApplicatioFormsPermissions.GroupName);
        //Define your own permissions here. Example:
        //myGroup.AddPermission(ApplicatioFormsPermissions.MyPermission1, L("Permission:MyPermission1"));
        //var applicationFormGroup = context.AddGroup(ApplicatioFormsPermissions.GroupName, L("Permission:applicationFormGroup"));

        var applicantDetailsPermission = myGroup.AddPermission(ApplicantDetails.Default, L("Permission:ApplicantDetails"));
        applicantDetailsPermission.AddChild(ApplicantDetails.Create, L("Permission:ApplicantDetails.Create"));
        applicantDetailsPermission.AddChild(ApplicantDetails.Edit, L("Permission:ApplicantDetails.Edit"));
        applicantDetailsPermission.AddChild(ApplicantDetails.Delete, L("Permission:ApplicantDetails.Delete"));
    }

    private static LocalizableString L(string name)
    {
        return LocalizableString.Create<ApplicatioFormsResource>(name);
    }
}
