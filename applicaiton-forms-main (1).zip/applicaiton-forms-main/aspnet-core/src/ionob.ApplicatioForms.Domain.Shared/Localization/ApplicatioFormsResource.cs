﻿using Volo.Abp.Localization;

namespace ionob.ApplicatioForms.Localization;

[LocalizationResourceName("ApplicatioForms")]
public class ApplicatioFormsResource
{

}
