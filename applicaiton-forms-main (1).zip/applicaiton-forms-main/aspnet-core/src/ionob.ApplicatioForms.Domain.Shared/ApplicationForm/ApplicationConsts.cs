﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ionob.ApplicatioForms.ApplicationForm
{
    public static class ApplicationConsts
    {
        public const string DbTablePrefix = "ApplicationForms";
        
    }
}
