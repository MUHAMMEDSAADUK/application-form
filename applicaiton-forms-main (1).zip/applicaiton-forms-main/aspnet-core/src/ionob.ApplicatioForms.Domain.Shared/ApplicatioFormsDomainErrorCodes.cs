﻿namespace ionob.ApplicatioForms;

public static class ApplicatioFormsDomainErrorCodes
{
    /* You can add your business exception error codes here, as constants */
}
