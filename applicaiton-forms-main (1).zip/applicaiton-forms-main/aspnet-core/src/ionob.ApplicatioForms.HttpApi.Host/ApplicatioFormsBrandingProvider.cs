﻿using Volo.Abp.DependencyInjection;
using Volo.Abp.Ui.Branding;

namespace ionob.ApplicatioForms;

[Dependency(ReplaceServices = true)]
public class ApplicatioFormsBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "ApplicatioForms";
}
