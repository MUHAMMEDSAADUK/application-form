﻿using ionob.ApplicatioForms.EntityFrameworkCore;
using Volo.Abp.Modularity;

namespace ionob.ApplicatioForms;

[DependsOn(
    typeof(ApplicatioFormsEntityFrameworkCoreTestModule)
    )]
public class ApplicatioFormsDomainTestModule : AbpModule
{

}
