﻿namespace ionob.ApplicatioForms;

public abstract class ApplicatioFormsDomainTestBase : ApplicatioFormsTestBase<ApplicatioFormsDomainTestModule>
{

}
