﻿namespace ionob.ApplicatioForms;

public abstract class ApplicatioFormsApplicationTestBase : ApplicatioFormsTestBase<ApplicatioFormsApplicationTestModule>
{

}
