﻿using Volo.Abp.Modularity;

namespace ionob.ApplicatioForms;

[DependsOn(
    typeof(ApplicatioFormsApplicationModule),
    typeof(ApplicatioFormsDomainTestModule)
    )]
public class ApplicatioFormsApplicationTestModule : AbpModule
{

}
