﻿using Volo.Abp;

namespace ionob.ApplicatioForms.EntityFrameworkCore;

public abstract class ApplicatioFormsEntityFrameworkCoreTestBase : ApplicatioFormsTestBase<ApplicatioFormsEntityFrameworkCoreTestModule>
{

}
